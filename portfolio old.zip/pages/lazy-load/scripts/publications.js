const dataURL = "data/exampledata.json";

const publishToShow = 5;

const LAST_PUBLISH_CLASS = "last-publish";

const publicationSection = () => document.querySelector(".publications");
const publicationsShowed = () => document.querySelectorAll(".publication").length;

const article = publication => {
    const article = document.createElement("ARTICLE");
    article.classList.add("publication");

    const perfil = document.createElement("DIV");
    perfil.classList.add("perfil-info");
    article.appendChild(perfil);

    const perfil_image = document.createElement("IMG");
    perfil_image.setAttribute("src", publication.image);
    perfil_image.setAttribute("alt", publication.name);
    perfil_image.setAttribute("onerror", "this.src='./images/nophoto.webp';");
    perfil.appendChild(perfil_image);

    const perfil_name = document.createElement("EM");
    perfil_name.classList.add("name");
    perfil_name.appendChild(document.createTextNode(publication.name));
    perfil.appendChild(perfil_name);

    const comment = document.createElement("P");
    comment.classList.add("comment");
    comment.appendChild(document.createTextNode(publication.comment));
    article.appendChild(comment);

    const reactions = document.createElement("DIV");
    reactions.classList.add("reacts-info");
    article.appendChild(reactions);

    const reactions_like_image = document.createElement("IMG");
    reactions_like_image.setAttribute("src", "./images/heart.webp");
    reactions_like_image.setAttribute("alt", "Like");
    reactions.appendChild(reactions_like_image);

    const reactions_comment_image = document.createElement("IMG");
    reactions_comment_image.setAttribute("src", "./images/comment.webp");
    reactions_comment_image.setAttribute("alt", "Comment");
    reactions.appendChild(reactions_comment_image);

    const reactions_like_p = document.createElement("P");
    reactions_like_p.classList.add("likes");
    reactions_like_p.appendChild(document.createTextNode(`${publication.likes} likes`));
    reactions.appendChild(reactions_like_p);

    const reactions_comment_p = document.createElement("P");
    reactions_comment_p.classList.add("comments");
    reactions_comment_p.appendChild(document.createTextNode(`${publication.comments} comentarios`));
    reactions.appendChild(reactions_comment_p);

    return article;
}

function showNewPublications() {
    console.clear();
    console.log("Publications showed:", publicationsShowed());
    console.log("New publications to show:", publishToShow);
    fetch("./data/exampledata.json")
    .then(response => response.json())
    .then(json => json.publications)
    .then(array => {// console.table(array);
        const totalPublications = publicationsShowed();
        for (let p = totalPublications; p < (totalPublications + publishToShow); p++) 
            showNewPublication(array[p], (p === (totalPublications + publishToShow - 1)) ? true : false);
    }).catch(() => console.log("No se encontró información."));
}

function showNewPublication(publicationInfo, isLast=false) {
    const htmlElement = article(publicationInfo);
    if (isLast) observe(htmlElement);
    publicationSection().appendChild(htmlElement);
}

function observe(htmlElement) {
    new IntersectionObserver(entries => {
        for (const entry of entries) if (entry.isIntersecting && entry.target.classList.contains(LAST_PUBLISH_CLASS)) {
            entry.target.classList.remove("last-publish");
            console.log("VISTO!");
            showNewPublications();
        }
    }).observe(htmlElement);
    htmlElement.classList.add(LAST_PUBLISH_CLASS);
}

window.onload = () => {
    publicationSection().innerHTML = "";
    showNewPublications();
}