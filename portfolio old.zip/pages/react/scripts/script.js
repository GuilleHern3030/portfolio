/* // JavaScript nativo
const $app = document.getElementById("app");

const Avatar = params => {
    const src = `https://randomuser.me/api/portraits/women/${params.id}.jpg`;
    return `<picture>
        <img src="${src}">
        <em>${params.name}</em>
    </picture>`;
};

$app.innerHTML += Avatar({ id: 1, name: "Andrea" });
$app.innerHTML += Avatar({ id: 2, name: "Manuela" });

// Al tocar una imagen, se deshabilita o habilita
$app.querySelectorAll('img').forEach(img => 
    img.addEventListener("click", () => 
        img.classList.toggle("disabled")
    )
);*/

const $app = document.getElementById("app");
const {useState} = React; // useState = React.useState;

const Avatar = ({id, name = 'un nombre'}) => {

    const [enabled, setEnabled] = useState(true) // valor inicial del estado
    const imgClassName = enabled ? '' : 'disabled';

    const src = `https://randomuser.me/api/portraits/women/${id}.jpg`;


    return (
        <picture>
            {
                id ? (
                    <img 
                        onClick={() => setEnabled(!enabled)} 
                        className={imgClassName} 
                        src={src}
                    />
                ) : (
                    <i>Sin imagen</i> 
                )
            }
            <em>{enabled ? name : "Desactivada"}</em>
        </picture>
    );
}

// Crea los elementos en el DOM
ReactDOM.render( 
    <div>
        <Avatar name="Andrea"/>
        <Avatar id={24} name="Andrea"/>
    </div>,
    $app // ---> será el htmlElement contenedor
);
