export class LocalData {
    static name = () => "Menú";
    static contactNumber = () => "541133664136";
    static coinSymbol = () => "$";
    static csvPath = () => './data/data.csv';
    static categoryHeader = () => 'CATEGORIA';
}