import { LocalData } from "../data/data.js"
import { ID } from "./CSVReader.js"

const NULL_DATA = "None";
const IMAGE_DEFAULT = "./icons/defaultimg.webp";
const BUTTON_ID_NAME = "article-buttons";

const CATEGORY_HEADER = "CATEGORIA";
const NAME_HEADER = "NOMBRE";
const PRICE_HEADER = "PRECIO";
const DESCRIPTION_HEADER = "DESCRIPCION";
const REGISTER_HEADER = "MARCA";
const AMOUNT_HEADER = "CANTIDAD";
const IMG_HEADER = "IMAGEN";
const EXTRA_DESCRIPTION_HEADER = "MAS INFO"
const ALTERNATE_PRICE_HEADER = "PRECIO ALTERNATIVO";

const outOfStockText = () => "Sin stock";

const setValidClass = (aClassName) => (isNull(aClassName)) ? NULL_DATA.toLowerCase() : aClassName.toString().toLowerCase().split(" ").join("_");
const isNull = (property) => (property == null || property == undefined || property == NaN || property == NULL_DATA);
const getSafeData = (data) => (isNull(data)) ? null : data;
const getSafeImg = (img) => (isNull(img)) ? IMAGE_DEFAULT : `./images/${img}.webp`;
const getSafePrice = (price) => (isNull(price)) ? 0 : price;
const getSafeAmount = (amount) => (isNull(amount)) ? null : (amount <= 0) ? 0 : amount;

export class Article {

    #articleObject;

    constructor(article) {
        if (typeof(article) == 'object') this.#articleObject = article;
        else throw Error("invalid article");
    }

    static htmlID = (article) => (typeof(article) == 'object') ? "article-" + article[ID] : "article-" + article;

    id = () => this.#articleObject[ID];
    htmlID = () => Article.htmlID(this.#articleObject);
    name = () => getSafeData(this.#articleObject[NAME_HEADER]);
    price = () => getSafePrice(this.#articleObject[PRICE_HEADER]);
    img = () => getSafeImg(this.#articleObject[IMG_HEADER]);
    register = () => getSafeData(this.#articleObject[REGISTER_HEADER]);
    category = () => getSafeData(this.#articleObject[CATEGORY_HEADER]);
    description = () => getSafeData(this.#articleObject[DESCRIPTION_HEADER]);
    extraDescription = () => getSafeData(this.#articleObject[EXTRA_DESCRIPTION_HEADER]);
    alternatePrice = () => getSafeData(this.#articleObject[ALTERNATE_PRICE_HEADER]);
    amount = () => getSafeAmount(this.#articleObject[AMOUNT_HEADER]);

    outOfStock = () => this.amount() === 0;
    amountHidden = () => (this.amount() === null || this.outOfStock());

    print = (htmlContainer) => {
        if (this.name() != null) {
        
            // <article>
            let htmlArticle = `<article id="${this.htmlID()}"`;
            htmlArticle += `class="article-name-${setValidClass(this.name())} article-category-${setValidClass(this.category())} article-amount-${setValidClass(this.amount())} article-register-${setValidClass(this.register())}">`;

            // ¿out of stock?
            if (this.outOfStock()) htmlArticle += `<div class="article-out" style="position: absolute;">${outOfStockText()}</div>`;

            // <div>
            htmlArticle += `
                <div class="article-img">
                    <div><img src="${this.img()}" alt="${this.name()}"></div>`;
            if (!this.amountHidden()) htmlArticle += `<p class="article-amount">${this.amount()} restantes</p>`;
            htmlArticle += `</div>`;

            // <div>
            htmlArticle += `<div class="article-info">`;
            if (this.name() !== null) htmlArticle += `<p class="article-info-name">${this.name()}</p>`;
            if (this.description() !== null) htmlArticle += `<p class="article-info-description">${this.description()}</p>`;
            if (this.price() !== null) {
                htmlArticle += `<p class="article-info-price">${LocalData.coinSymbol()} ${this.price()}`;
                if (this.alternatePrice() !== null) htmlArticle += `<span class="article-info-alternateprice"><br>${this.alternatePrice()}</span>`;
            }
            htmlArticle += `</p></div>`;

            htmlArticle += `<div class="${BUTTON_ID_NAME}" id="${this.htmlButtonID()}">`;
            if (!this.outOfStock()) htmlArticle += `
                <button class="${BUTTON_ID_NAME}-addition">+</button>
                <input id="input-${this.htmlID()}" class="${BUTTON_ID_NAME}-input" type="number" name="ammount-${this.htmlID()}" required="" value="0" min=0 max=${this.amount()}></input>
                <button class="${BUTTON_ID_NAME}-substract">-</button>
            `;
            htmlArticle += `</div>`;

            htmlContainer.innerHTML += htmlArticle + "</article>";
        }
    }
    
    ticketHTMLLine = (amount) => (getSafePrice(this.price()) > 0) ? `<li>- ${this.name()}: ${LocalData.coinSymbol()} ${this.price()}    x ${amount}</li>` : `<li>- ${this.name()}    x ${amount}</li>`;

    htmlButtonID = () => `${BUTTON_ID_NAME}-${this.id()}`;

    async addEvents(htmlArticleInfoContainer) {
        const article = document.getElementById(this.htmlID());

        // Add / Substract buttons
        try {
            const buttonZone = document.getElementById(this.htmlButtonID());
            const buttonAddition = buttonZone.children[0];
            const buttonSubstract = buttonZone.children[2];
            const input = buttonZone.children[1];
            buttonZone.addEventListener("click" , e => e.stopPropagation());
            buttonAddition.addEventListener("click", e => {
                input.value = (Number(input.value) >= Number(input.max)) ? input.max : Number(input.value) + 1; 
                e.stopPropagation();
            });
            buttonSubstract.addEventListener("click", e => { 
                input.value = (Number(input.value) <= 0) ? 0 : Number(input.value) - 1; e.stopPropagation(); 
            });
        } catch(e) { 
            console.warn(this.name() + " has no stock");
            article.style.transform = "None";
        }

        // Show article button
        try {
            article.addEventListener("click" , e => {
                this.showArticleInfo(htmlArticleInfoContainer);
                e.stopPropagation();
            });
        } catch(e) { console.error(this.name() + "\n" + e); }
    }

    async showArticleInfo(htmlContainer) {
        let htmlArticle = "";
        htmlContainer.innerHTML = "";
        htmlContainer.style.display = "flex";

        htmlArticle += `<div class="article-showed">
            <p class="article-info-name">${this.name()}</p>
            <div class="article-img article-img-showed"><img src="${this.img()}" alt="${this.name()}"></div>`
            
            if (this.name() !== null) htmlArticle += ``;
            if (this.description() !== null) htmlArticle += `<p class="article-info-description-showed">${this.description()}</p>`;
            if (this.extraDescription() !== null) htmlArticle += `<p class="article-info-description-showed">${this.extraDescription()}</p>`;
            if (this.price() !== null) {
                htmlArticle += `<p class="article-info-price">$${this.price()}</p>`;
                if (this.alternatePrice() !== null) htmlArticle += `<p class="article-info-alternateprice">${this.alternatePrice()}</p>`;
            }

        htmlContainer.innerHTML += htmlArticle + "</div>";

        setTimeout(() => htmlContainer.firstElementChild.classList.add("article-showed-animation"));
        
        htmlContainer.addEventListener("click", e => { this.hideArticleInfo(htmlContainer); e.stopPropagation(); });
        htmlContainer.firstElementChild.addEventListener("click", e => e.stopPropagation() );
        htmlContainer.firstElementChild.lastElementChild.addEventListener("click", e => { onArticleShowedButtonClicked(article); e.stopPropagation(); });
    }

    async hideArticleInfo(htmlContainer) {
        htmlContainer.firstElementChild.classList.remove("article-showed-animation");
        setTimeout(() => { htmlContainer.style.display = "none"; htmlContainer.innerHTML = ""; }, 250);
    }
}
