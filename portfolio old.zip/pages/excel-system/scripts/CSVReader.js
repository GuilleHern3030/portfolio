import { Article } from "./Article.js"

export const SEPARATOR = "~";
export const NEW_LINE = "\r\n";
export const ID = "ID";

const getData = (data) => {
    const content = data.split(NEW_LINE);
    const headers = ((content).shift()).split(SEPARATOR);

    for (let i = 0; i < (content).length; i++)
        content.push((content.shift()).split(SEPARATOR));
    
    return [headers, content];
}

export const loadCSV = (csvPath) => {
    return new Promise((resolve, reject) => {
        fetch(csvPath)
        .then(response => (response.ok) ? response.text() : null)
        .then(data => {
            const content = getData(data);
            resolve(new CSVReader(csvPath, content[0], content[1]));

        }).catch(e => { reject("Data not found.\n" + e); });
    });
}

class CSVReader {

    #csvPath;
    #csvHeaders;
    #csvContent;

    constructor(csvPath, headers, content) {
        this.#csvPath = csvPath;
        this.#csvHeaders = headers;
        this.#csvContent = content;
    }

    reloadCSV = () => new Promise((resolve, reject) => {
        fetch(this.#csvPath)
        .then(response => (response.ok) ? response.text() : null)
        .then(data => {
            const reloadedData = getData(data);
            this.#csvHeaders = reloadedData[0];
            this.#csvContent = reloadedData[1];
            resolve();
        }).catch(() => { reject("Data not found."); });
    });


    isPathLoaded() { 
        if (this.#csvPath === undefined)
            throw Error("csv is not loaded");
        return true;
    }

    content = () => this.isPathLoaded() ? this.#csvContent.slice() : null;

    headers = () => this.isPathLoaded() ? this.#csvHeaders.slice() : null;

    headerIndex = (headerTitle) => this.isPathLoaded() ? (this.#csvHeaders).indexOf(headerTitle) : null;

    length = () => (this.#csvPath === undefined) ? 0 : this.#csvContent.length;

    /**
     * Selecciona una fila del CSV
     * @param {number} id Número de fila dentro del CSV, iniciando en 0
     * @returns {object} Devuelve un objeto con los datos de la fila
     */
    selectById(id) {
        this.isPathLoaded();
        const element = {};
        element[ID] = id;
        for (let h = 0; h < this.#csvHeaders.length; h++)
            element[this.#csvHeaders[h]] = this.#csvContent[id][h];
        return new Article(element);
    }

    /**
     * Selecciona un conjunto de filas del CSV según el header en común
     * @param {string} headerTitle Nombre del header a evaluar
     * @param {string} headerToSelect Nombre del header definido en la fila
     * @param {boolean} caseSensitive Establece si el header es sensible a mayúsculas
     * @returns {array} Devuelve un array de objetos con los datos de cada fila que comparten el headerTitle
     */
    selectByHeaderName(headerTitle, headerToSelect, caseSensitive = true) {
        const headerIndex = this.headerIndex(headerTitle);
        const elements = [];
        for (let row in this.#csvContent) 
            if(caseSensitive && this.#csvContent[row][headerIndex] == headerToSelect
            || !caseSensitive && this.#csvContent[row][headerIndex].toLowerCase() == headerToSelect.toLowerCase()) 
                elements.push(this.selectById(row));
        return elements;
    }

    /**
     * Obtiene todas las variables de contenidos de una columna de un header específico
     * @param {string} headerTitle Nombre del header a evaluar
     * @returns {array} Devuelve un array con todas las variantes de contenidos de una columna
     */
    getContentByHeader(headerTitle) {
        const headers = [];
        const headerIndex = this.headerIndex(headerTitle);
        for (let row in this.#csvContent) 
            if (!headers.includes(this.#csvContent[row][headerIndex])) 
                headers.push(this.#csvContent[row][headerIndex]);
        return headers;
    }

}
