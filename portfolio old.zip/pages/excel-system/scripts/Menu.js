import { LocalData } from "../data/data.js";

const HTML_ARTICLES_SECTION = document.getElementById("section-menu");
const HTML_ARTICLE_ASIDE = document.getElementById("article-summary");
const HTML_NAV = document.getElementById("nav-ul");


// Categories
const htmlCategoryID = (id) => `category-${id}`;
const setValidClass = (aClassName) => aClassName.toLowerCase().split(" ").join("_");
function printCategories(categories = null) {
    try {
        if (categories !== null) for (let i in categories) {
            HTML_ARTICLES_SECTION.innerHTML += `
                <div id="${htmlCategoryID(i)}" class="article-category article-category-${setValidClass(categories[i])}">
                    <p class="article-category-title">${categories[i]}</p>
                </div>`;
        }
    } catch(e) { console.error(e); }
}


// Nav
/*
    <div class="nav">
        <ul id="nav-ul">
        </ul>
    </div>
*/
async function printNav(categories = null) {
    if (categories !== null) {
        createNav(categories);
        assignOnClickFunctionToNav(categories);
    }
}

function createNav(categories) {
    let htmlCode = "";
    for (let i in categories) htmlCode += `<li><a href="#${htmlCategoryID(i)}">${categories[i]}</a></li>`;
    HTML_NAV.innerHTML = htmlCode;
}

function assignOnClickFunctionToNav(categories) {
    for (let i in categories) document.querySelector(`a[href='#${htmlCategoryID(i)}']`).addEventListener("click", e => {
        e.preventDefault(); // Evita el comportamiento predeterminado del enlace
        scrollTo(htmlCategoryID(i));
    });
}

function scrollTo(htmlElementId) {
    const articleCategorySize = 3.5; // vw (defined in styles)

    const destiny = document.getElementById(htmlElementId);
    const scrolled = window.scrollY || window.pageYOffset;
    const posTop = destiny.getBoundingClientRect().y + scrolled;
    const pageWidth = document.documentElement.clientWidth;

    const offset = (articleCategorySize / 33) * pageWidth;

    window.scrollTo({
        top: posTop - offset,
        behavior: "smooth"
    });
}


// Articles
async function printArticles(categories = null, articles) {
    createArticles(categories, articles);
    assignOnClickFunctionToArticles(articles);
}

function createArticles(categories = null, articles) {
    if (categories !== null) {
        for (let category of categories) 
            (articles.selectByHeaderName(LocalData.categoryHeader(), category))
            .forEach(article => createArticle(article, category));
    } else for (let id = 0; id < articles.length; id ++) (articles.selectById(id).print());
}

function createArticle(article, category = null) {
    try {
        const htmlContainer = (category === null) ? HTML_ARTICLES_SECTION : document.querySelector(`.article-category-${setValidClass(category)}`)
        article.print(htmlContainer);
    } catch(e) { console.error(e); }
}

function assignOnClickFunctionToArticles(articles) {
    for (let i = 0; i < articles.length(); i ++) try {
        articles.selectById(i).addEvents(HTML_ARTICLE_ASIDE);
    } catch(e) { console.error(e); }
}


export class Menu {

    constructor(csv) {
        let categories = csv.getContentByHeader(LocalData.categoryHeader());

        HTML_ARTICLES_SECTION.innerHTML = "";
        HTML_NAV.innerHTML = "";
        printCategories(categories);
        printArticles(categories, csv);
        printNav(categories);
    }
}