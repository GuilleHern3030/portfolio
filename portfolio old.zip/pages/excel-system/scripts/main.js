import { LocalData } from "../data/data.js";
import { loadCSV } from "./CSVReader.js";
import { Menu } from "./Menu.js";
import { ShoppingCart } from "./ShoppingCart.js";

window.onload = () => {
    document.getElementById("pagetitle").innerHTML = LocalData.name();
    loadCSV(LocalData.csvPath()).then(csv => {
        new Menu(csv);
        new ShoppingCart(csv);
    }).catch(err => { console.error(err); } );
}