import { LocalData } from "../data/data.js";

/*
    <div id="shopping-cart"> 
        <div class ="shopping-cart-icon">
            <img src="./images/shoppingcart.png">
        </div>
        <ul class="shopping-cart-ul"></ul>
    </div>
*/

const BUTTON_TEXT = "Pedir";
const PURCHASE_BUTTON_ID = "purchase";

const sendMessage = (message) => window.open('https://wa.me/' + LocalData.contactNumber() + '?text=' + encodeURIComponent(message), '_blank');

const legalPrice = (price) => (price != null) ? price : 0;  

const articleSelected = (htmlInput, allArticles) => {
    const articleIDData = (htmlInput.closest("article").id).split("-");
    return {
        "article": allArticles.selectById(articleIDData[(Number(articleIDData.length) - 1)]),
        "amount": htmlInput.value
    };
}

const getArticlesSelected = (allArticles) => {
    const articles = [];
    for(let input of document.getElementsByTagName("input")) 
        if (input.value > 0)
            articles.push(articleSelected(input, allArticles));
    return articles;
}

const printTicket = (menu, articles) => {
    let items = 0;
    let totalPrice = 0;
    let existArticlesWithoutPrice = false;
    let result = `<li class="shopping-list-title">Lista de la compra</li>`;
    for (let selection of articles) {
        result += selection["article"].ticketHTMLLine(selection["amount"]);
        let price = (legalPrice(selection["article"].price()) * selection["amount"]);
        totalPrice += price;
        if (price === 0) existArticlesWithoutPrice = true;
        items ++;
    }
    if (items > 0) {
        result += `<li class="shopping-list-total">Coste total: ${LocalData.coinSymbol()} ${totalPrice}</li>`
        result += `<li class="shopping-list-order"><button id="${PURCHASE_BUTTON_ID}"">${BUTTON_TEXT}</button></li>`
        if (existArticlesWithoutPrice) result += `<li">* Hay artículos sin precio definido, por lo que el coste total es estimativo</li>`;
    }
    else result += ` 
        <li>Aún no has seleccionado ningún artículo.</li>
        <li>¿Necesitas ayuda? Contáctanos <button id="${PURCHASE_BUTTON_ID}">presionando aquí</button>.</li>
        `;
    menu.innerHTML = result;
}

const assignFunctionToPurchaseButton = (shoppingCart) => {
    document.getElementById(PURCHASE_BUTTON_ID).addEventListener("click", e => { 
        e.preventDefault(); 
        shoppingCart.purchase();
    });
}

export class ShoppingCart {

    #data;
    #icon;
    #menu;
    #timer;
    #articlesSelected;

    constructor(csv) {
        this.#data = csv;
        this.#icon = document.querySelector(".shopping-cart-icon");
        this.#menu = document.querySelector(".shopping-cart-ul");

        this.#icon.addEventListener("click", () => {
            if (this.#icon.classList.contains("shoppingcart-icon__active")) this.hideMenu();
            else this.showMenu();
        });
    }

    hideMenu = () => {
        this.#icon.classList.toggle("shoppingcart-icon__inactive", true);
        this.#icon.classList.toggle("shoppingcart-icon__active", false);
        this.#menu.classList.toggle("shoppingcart-content__inactive", true);
        this.#menu.classList.toggle("shoppingcart-content__active", false);
        this.#timer = setTimeout(() => this.#menu.style.display = "none", 200);
    }

    showMenu = () => {   
        clearTimeout(this.#timer);     
        this.#icon.classList.toggle("shoppingcart-icon__active", true);
        this.#icon.classList.toggle("shoppingcart-icon__inactive", false);
        this.#menu.classList.toggle("shoppingcart-content__active", true);
        this.#menu.classList.toggle("shoppingcart-content__inactive", false);
        this.#menu.style.display = "flex";
        this.#articlesSelected = getArticlesSelected(this.#data);
        printTicket(this.#menu, this.#articlesSelected);
        assignFunctionToPurchaseButton(this);
    }

    purchase = () => {
        let article;
        let total = 0;
        let message = "Hola, estoy en su página web y quiero pedir:";
        if (this.#articlesSelected.length > 0) {
            this.#data.reloadCSV().then(() => {
                let existArticlesWithoutPrice = false;
                for(let articleSelected of this.#articlesSelected) {
                    article = this.#data.selectById(articleSelected["article"].id());
                    message += `\n - ${article.name()} (${LocalData.coinSymbol()} ${legalPrice(article.price())}) x ${articleSelected["amount"]}`;
                    let price = (Number(legalPrice(article.price())) * Number(articleSelected["amount"]));
                    total += price;
                    if (price === 0) existArticlesWithoutPrice = true;
                }
                if (!existArticlesWithoutPrice) message += `\n----[ TOTAL ESTIMADO: ${LocalData.coinSymbol()} ${total} ]----`;
                sendMessage(message);
            }).catch(err => { console.error(err); });
        } else sendMessage("Hola, estoy viendo su página web y necesito ayuda.");
        
    }

}