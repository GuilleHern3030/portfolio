

const version = "version 2"; // ejemplo
self.addEventListener("install", e => {
    console.log("Instalando ServiceWorker");
    caches.open(version).then(cache => {
        cache.add("index.html")
        .then(response => {
            console.log("Información cacheada");
        }).catch(e => { 
            console.log(e); 
        });
    });
});

self.addEventListener("activate", e => {
    console.log("Activando ServiceWorker");
    caches.keys().then(key => Promise.all(
        key.map(cache => {
            if (cache !== version) {
                console.log("caché antiguo borrado");
                return caches.delete(cache);
            }
        })
    ));
});

self.addEventListener("error", e => {
    /* Este código se ejecutará cuando
    el service worker tenga un error */
    console.log(e);
    console.log("activado");
});

self.addEventListener("fetch", e => {
    e.respondWith(caches.match(e.request).then(response => response || fetch(e.request)))
});

self.addEventListener("message", e => {
    console.log("Mensaje recibido:");
    console.log(e.data);

    // Enviar mensaje al script de origen
    e.source.postMessage("OTRO MENSAJE");
});