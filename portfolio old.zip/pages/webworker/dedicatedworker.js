
addEventListener("message", e => {
    console.log(e); // Objeto MessageEvent
    console.log(e.data); // "Aloja"
    postMessage("Este mensaje será devuelto a script.js");
});

