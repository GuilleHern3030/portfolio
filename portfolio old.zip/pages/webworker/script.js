
const serviceworker = navigator.serviceWorker;
if (serviceworker) { 

    // Instalar o abrir
    serviceworker.register("serviceworker.js");

    /*// Enviar mensaje al ServiceWorker
    serviceworker.ready.then(response => {
        response.active.postMessage("MENSAJE");
    });

    // Recibir mensaje del ServiceWorker
    serviceworker.addEventListener("message", e => {
        console.log(e.data);
    });*/

} else console.log("Service Worker no soportado!");