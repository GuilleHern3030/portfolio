const print = (propName, prop) => {
    console.log(propName + ":");
    console.log(prop);
    console.log("");
}


// Propiedades

print ("AppCodeName", navigator.appCodeName); // No siempre es correcto
print ("AppName", navigator.appName); // No siempre es correcto
print ("AppVersion", navigator.appVersion); // No siempre es correcto
print ("UserAgent", navigator.userAgent); // No siempre es correcto
print ("Geolocation", navigator.geolocation); // Objeto GeoLocation
print ("HardwareConcurrency", navigator.hardwareConcurrency); // Núcleos del procesador
print ("Language", navigator.language); // Idioma del usuario o del navegador
print ("Languages", navigator.languages); // Array de idiomas del usuario
print ("MimeTypes", navigator.mimeTypes); // Tipos de archivos que se pueden usar en NodeJS
print ("OnLine", navigator.onLine); // Verifica que se esté conectado a internet
print ("CookiesEnabled", navigator.cookieEnabled); // Verifica que se hayan aceptado cookies
print ("Permissions", navigator.permissions); // Permisos del navegador
print ("Platform", navigator.platform); // win32 o win64, Mac, Linux
print ("Plugins", navigator.plugins); // Plugins instalados
print ("Product", navigator.product); // Gecko
print ("ServiceWorker", navigator.serviceWorker);