import { connectDataBase as connect } from "./BasicDB.js";
import { InputGetter } from "./InputGetter.js";

const key = new URLSearchParams(window.location.search).keys().next().value;
const id = new URLSearchParams(window.location.search).get(key);
const jsonid = {};
jsonid[key] = id;

const inputs = new InputGetter();

const hide = (element) => element.classList.toggle("hidden", true);
const show = (element) => element.classList.remove("hidden");

window.onload = async () => {

    if (id == null) { window.location.href = `producto_crear.html`; }
    else try {

        const warnDiv = document.querySelector(".form-container__warningcontainer");
        const submitButton = document.getElementById("submit");

        const db = await connect("cfp33curso");
        await db.setTable("usuarios");

        const data = await db.read(jsonid);
        console.table(data);

        const inputElements = document.querySelectorAll(".input");
        inputElements.forEach(input => {
            if (data[input.name] != undefined) input.value = data[input.name];
            inputs.add(input);
        });

        submitButton.addEventListener("click", async () => {
            if (inputs.isAllValid()) {
                hide(warnDiv);
                const success = await db.edit(jsonid, inputs.json());
                if (success) window.location.href = `producto_lista.html`;
                else submitButton.innerHTML = "Error";
            } else show(warnDiv);
        });

        submitButton.removeAttribute("disabled");
        submitButton.classList.toggle("form-container__button-disabled", false);
        submitButton.classList.toggle("form-container__button-enabled", true);

        show(document.querySelector(".form-container"));

    } catch(err) {
        console.error(err);
    }
}