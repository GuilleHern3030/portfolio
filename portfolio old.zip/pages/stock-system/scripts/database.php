<?php

const MYSQL_KEY_SERVER = "mysql-servername";
const MYSQL_KEY_USER = "mysql-username";
const MYSQL_KEY_PASSWORD = "mysql-password";
const MYSQL_KEY_DBNAME = "mysql-dbname";
const MYSQL_KEY_TABLE = "mysql-tablename";
const MYSQL_KEY_OPERATION = "mysql-operation";
const MYSQL_KEY_INDEX = "mysql-index";
const MYSQL_KEY_NEWDATA = "mysql-newdata";

$mysql_data = array( // key => value
    MYSQL_KEY_SERVER => "localhost",
    MYSQL_KEY_USER => "root",
    MYSQL_KEY_PASSWORD => "",
    MYSQL_KEY_DBNAME => "",
    MYSQL_KEY_TABLE => "",
    MYSQL_KEY_OPERATION => "undefined",
    MYSQL_KEY_NEWDATA => null,
    MYSQL_KEY_INDEX => ""
);

$GET = $_GET;
$POST = ($_POST) ? $_POST : json_decode(file_get_contents("php://input"), true);
foreach ($mysql_data as $key => $value) {
    if (($_POST || $_SERVER["REQUEST_METHOD"] === "POST") && isset($POST[$key])) $mysql_data[$key] = $POST[$key];
    elseif (($GET || $_SERVER["REQUEST_METHOD"] === "GET") && isset($GET[$key])) $mysql_data[$key] = $GET[$key];
    unset($GET[$key]);
    unset($POST[$key]);  // example: '{"nombre":"Juan","edad":"30","ciudad":"México"}'
}

function secureString($text) {
    return stripslashes(htmlspecialchars($text));
}

include("MySQL.php");

$db = new MySQL(
            $mysql_data[MYSQL_KEY_SERVER], 
            $mysql_data[MYSQL_KEY_USER],
            $mysql_data[MYSQL_KEY_PASSWORD],
            $mysql_data[MYSQL_KEY_DBNAME]
        );

try {

    $result = array("mysql-error" => "An error has been ocurred.");

    if ($mysql_data[MYSQL_KEY_OPERATION] === "add")
        $result = ($db -> add(
            $mysql_data[MYSQL_KEY_TABLE],
            $POST
        )) ?
            array("mysql-result" => "true") : 
            array("mysql-result" => "false");

    elseif ($mysql_data[MYSQL_KEY_OPERATION] === "edit") {

        $result = ((!empty($mysql_data[MYSQL_KEY_INDEX]))) ? 
            $db -> editByIndex($mysql_data[MYSQL_KEY_TABLE], $mysql_data[MYSQL_KEY_INDEX], $POST) :
            $db -> edit($mysql_data[MYSQL_KEY_TABLE], $POST, $mysql_data[MYSQL_KEY_NEWDATA]);
    }

    elseif ($mysql_data[MYSQL_KEY_OPERATION] === "remove") {

        $result = ((!empty($mysql_data[MYSQL_KEY_INDEX]))) ? 
            $db -> deleteByIndex($mysql_data[MYSQL_KEY_TABLE], $mysql_data[MYSQL_KEY_INDEX]) :
            $db -> delete($mysql_data[MYSQL_KEY_TABLE], $POST);
            
    }

    elseif ($mysql_data[MYSQL_KEY_OPERATION] === "read")
        $result = ((!empty($mysql_data[MYSQL_KEY_INDEX]))) ? 
            $db -> readByIndex($mysql_data[MYSQL_KEY_TABLE], $mysql_data[MYSQL_KEY_INDEX]) :
            $db -> read($mysql_data[MYSQL_KEY_TABLE], $POST);

    elseif ($mysql_data[MYSQL_KEY_OPERATION] === "serverinfo") 
        $result = $db -> serverinfo();

    elseif ($mysql_data[MYSQL_KEY_OPERATION] === "readall") 
        $result = $db -> readAll($mysql_data[MYSQL_KEY_TABLE]);

    elseif ($mysql_data[MYSQL_KEY_OPERATION] === "isconnected")
        $result = $db -> isConnected();

    elseif ($mysql_data[MYSQL_KEY_OPERATION] === "maxindex") 
        $result = $db -> maxIndex($mysql_data[MYSQL_KEY_TABLE]);

    elseif ($mysql_data[MYSQL_KEY_OPERATION] === "maxid")
        $result = $db -> maxId($mysql_data[MYSQL_KEY_TABLE], 'id');

    elseif ($mysql_data[MYSQL_KEY_OPERATION] === "close") {    
        $db -> close();
        $result = true;        
    } else throw new Exception("Invalid operation ". $mysql_data[MYSQL_KEY_OPERATION]);

    $db -> echo($result);

} 
catch (Exception $e) { $db -> echo(array("error" => $e -> getMessage())); } 
catch (Error $e) { $db -> echo(array("error" => $e -> getMessage())); } 
finally { $db -> close(); }

die(); // */
?>