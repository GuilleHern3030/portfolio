<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cfp33curso";
$tablename = "usuarios";

$operation = "read";

function secureString($text) {
    return stripslashes(htmlspecialchars($text));
}

/*if ($_GET) { // Hay parámetros de método GET
    if (isset($_GET['servername'])) $servername = secureString($_GET['servername']);
    if (isset($_GET['username'])) $username = secureString($_GET['username']);
    if (isset($_GET['password'])) $password = secureString($_GET['password']);
    if (isset($_GET['dbname'])) $dbname = secureString($_GET['dbname']);
    if (isset($_GET['tablename'])) $tablename = secureString($_GET['tablename']);
    if (isset($_GET['operation'])) $operation = secureString($_GET['operation']);
}

if ($_POST || $_SERVER["REQUEST_METHOD"] === "POST") try { // Hay parámetros de método POST
    $POST_DATA = ($_POST) ? $_POST : json_decode(file_get_contents("php://input"), true);
    if (isset($POST_DATA['servername'])) $servername = secureString($POST_DATA['servername']);
    if (isset($POST_DATA['username'])) $username = secureString($POST_DATA['username']);
    if (isset($POST_DATA['password'])) $password = secureString($POST_DATA['password']);
    if (isset($POST_DATA['dbname'])) $dbname = secureString($POST_DATA['dbname']);
    if (isset($POST_DATA['tablename'])) $tablename = secureString($POST_DATA['tablename']);
    unset($POST_DATA); // elimina la variable
} catch(Exception) { }
//else die(); // Si esta línea está habilitada, sólo se permiten datos post*/

try {

    $connection = mysqli_connect($servername,$username,$password,$dbname);



    if ($operation === "add") {

        $query = mysqli_query($connection, 
        "INSERT INTO $nombre_tabla (nombre, descripcion, cantidad) VALUE ('$nombre','$descripcion','$cantidad')"
        );

        echo '{'; 
        echo '"ok": "';
        echo "true";
        echo '"}';

    }

    elseif ($operation === "edit") {
        
    }

    elseif ($operation === "remove") {
        
    }

    elseif ($operation === "load") {
        
    }

    elseif ($operation === "read") {
    
        $query = mysqli_query($connection, "SELECT * FROM $tablename");

        $row = mysqli_fetch_assoc($query);

        if($row == null) throw new Exception("No database or table is not found");

        $data = array();
        do $data[] = $row;
        while ($row = mysqli_fetch_assoc($query));

        header('Content-Type: application/json');
        echo json_encode((object)$data);
        
    } else throw new Exception("Invalid operation");

} catch (Exception $e) { 

    echo '{'; 
    echo '"error": "';
    echo $e -> getMessage();
    echo '"}';
    
} finally {

    $connection -> close();
    unset($connection);

}

die();
?>