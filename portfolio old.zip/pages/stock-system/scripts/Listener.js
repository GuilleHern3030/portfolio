// Objeto que actúa como "emisor" de eventos
export const eventSender = {
    listeners: {},
    
    // Función para registrar un listener para un evento específico
    suscribir: function(evento, callback) {
      if (!this.listeners[evento]) {
        this.listeners[evento] = [];
      }
      this.listeners[evento].push(callback);
    },
    
    // Función para emitir un evento y llamar a todos los listeners registrados
    emitir: function(evento, datos) {
      if (this.listeners[evento]) {
        this.listeners[evento].forEach(function(callback) {
          callback(datos);
        });
      }
    }
};