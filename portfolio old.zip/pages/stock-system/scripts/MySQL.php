<?php

const MIN_INDEX = 1;

class MySQL {
    private $connection;
    private $isConnected;

    public function __construct(string $servername, string $username, string $password, string $dbname) {
        try { 
            $this -> connection = mysqli_connect($servername,$username,$password,$dbname); 
            $this -> isConnected = true;
        } catch(Error|Exception) {
            $this -> isConnected = false;
        }
    }

    /**
     * Convierte un JSON en una cláusula de WHERE
     * @param array $json Objeto JSON con la información del WHERE
     * @return string Devuelve la cláusula del WHERE válida
     */
    private function whereClause(array $json): string {
        $whereClause = "";
        foreach ($json as $key => $value) {
            if (!empty($whereClause)) $whereClause = $whereClause . " AND ";
            $whereClause = $whereClause . "$key = '$value'";
        }
        return "(" . $whereClause . ")";
    }

    public function isConnected(): bool {
        return $this -> isConnected;
    }

    /**
     * Lee toda la tabla de una base de datos
     * @param string $tablename Nombre de la tabla
     * @return object Devuelve la información de la tabla en formato JSON
     */
    public function readAll(string $tablename) {
        if (!$this -> isConnected) throw new Exception("Not connected.");

        $query = mysqli_query($this -> connection, "SELECT * FROM $tablename");

        $row = mysqli_fetch_assoc($query);

        if($row == null) throw new Exception("Table is not found or is empty.");

        $data = array();
        do $data[] = $row;
        while ($row = mysqli_fetch_assoc($query));

        return (object)$data; // asociated array
    }

    /**
     * Lee cierta información de una tabla de una base de datos
     * @param string $tablename Nombre de la tabla
     * @param array $rowdata Selección de la fila a leer, por ejemplo, { "id" : "3" } selecciona la fila con id 3
     * @return array Devuelve la información de la fila en formato JSON
     */
    public function read(string $tablename, array $jsonWhere): array {
        if (!$this -> isConnected) throw new Exception("Not connected.");
        
        $whereClause = $this -> whereClause($jsonWhere);

        $query = mysqli_query($this -> connection, "SELECT * FROM $tablename WHERE $whereClause");

        $row = mysqli_fetch_assoc($query);

        if ($row === null) throw new Exception("Not found.");

        return $row;
    }

    /**
     * Lee los datos de una fila de una tabla según el índice (no del id)
     * @param string $tablename Nombre de la tabla
     * @param int $index index que se busca
     * @return array Devuelve la información de la fila en formato JSON
     */
    public function readByIndex(string $tablename, int $index) {
        if (!$this -> isConnected) throw new Exception("Not connected.");
        if ($index < MIN_INDEX) throw new Exception("Invalid index.");

        $query = mysqli_query($this -> connection, "SELECT * FROM $tablename");

        for ($i = 0; $i < $index; $i ++) {
            $row = mysqli_fetch_assoc($query);
            if($row == null) throw new Exception("Index out of bounds.");
        }

        return $row;
    }

    /**
     * Añade un dato en una tabla
     * @param string $tablename Nombre de la tabla
     * @param object $values objeto JSON que contiene la información, cuyos key serán las columnas de la tabla
     * @return boolean True si logró añadirse la fila
     */
    public function add(string $tablename, array $values) {
        if (!$this -> isConnected) throw new Exception("Not connected.");

        if (is_string($values)) $json = json_decode($values, true);
        elseif (is_array($values) && array_keys($values) !== range(0, count($values) - 1)) $json = $values;
        else throw new Exception("Invalid data format.");

        $_headers = [];
        $_values = [];
        
        foreach ($json as $header => $value) {
            $_headers[] = $header;
            $_values[] = "'" . $value . "'";
        }

        $_values = implode(", ", $_values);
        $_headers = implode(", ", $_headers);

        $query = "INSERT INTO $tablename ($_headers) VALUE ($_values)";

        return mysqli_query($this -> connection, $query); // boolean
        
    }

    /**
     * Borra una fila de una tabla de una base de datos
     * @param string $tablename Nombre de la tabla
     * @param array $rowdata Selección de la fila a borrar, por ejemplo, { "id" : "3" } selecciona la fila con id 3
     * @return boolean True si logró eliminarse la fila
     */
    public function delete(string $tablename, array $rowdata): bool {
        if (!$this -> isConnected) throw new Exception("Not connected.");
        $whereClause = $this -> whereClause($rowdata);
        return mysqli_query($this -> connection, "DELETE FROM $tablename WHERE $whereClause");
    }

    /**
     * Borra una fila de una tabla de una base de datos según el índice (no del id)
     * @param string $tablename Nombre de la tabla
     * @param int $index index que se busca eliminar
     * @return boolean True si logró eliminarse la fila
     */
    public function deleteByIndex(string $tablename, int $index): bool {
        $row = $this -> readByIndex($tablename, $index);
        return $this -> delete($tablename, $row);
    }

    /**
     * Edita una fila de una tabla de una base de datos
     * @param string $tablename Nombre de la tabla
     * @param array $rowdata Selección de la fila a editar, por ejemplo, { "id" : "3" } selecciona la fila con id 3
     * @param array $newrowdata Nueva información de la fila
     * @return boolean True si logró editarse la fila
     */
    public function edit(string $tablename, array $rowdata, array $newrowdata) {
        if (!$this -> isConnected) throw new Exception("Not connected.");

        $whereClause = $this -> whereClause($rowdata);
        $query = "UPDATE $tablename SET ";
        foreach ($newrowdata as $key => $value) $query = $query . "$key = '$value',";
        $query = substr($query, 0, -1) . " WHERE $whereClause";

        return mysqli_query($this -> connection, $query);
        
    }

    /**
     * Edita una fila de una tabla de una base de datos según el índice (no del id)
     * @param string $tablename Nombre de la tabla
     * @param $index index que se busca editar
     * @param $newrowdata Nueva información de la fila
     * @return boolean True si logró editarse la fila
     */
    public function editByIndex(string $tablename, $index, $newrowdata) { 
        $rowdata = $this -> readByIndex($tablename, $index);
        return $this -> edit($tablename, $rowdata, $newrowdata);
    }

    /**
     * Cierra la base de datos mysql
     */
    public function close() {
        try { $this -> connection -> close(); } catch(Exception|Error) { }
    }

    /**
     * Obtiene la cantidad de filas de la tabla
     * @param string $tablename Nombre de la tabla
     * @return array Devuelve la información en formato JSON
     */
    public function maxIndex(string $tablename) {
        if (!$this -> isConnected) throw new Exception("Not connected.");
        $query = mysqli_query($this -> connection, "SELECT COUNT(*) as total_rows FROM $tablename;");
        return mysqli_fetch_assoc($query);
    }

    /**
     * Obtiene el id máximo de la tabla
     * @param string $tablename Nombre de la tabla
     * @param string $id_header Nombre de la columna que contiene el id
     * @return array Devuelve la información en formato JSON
     */
    public function maxId(string $tablename, string $id_header) {
        if (!$this -> isConnected) throw new Exception("Not connected.");
        $maxid = 0;
        try {
            $query = mysqli_query($this -> connection, "SELECT * FROM $tablename");
            $row = mysqli_fetch_assoc($query);
            if($row == null) throw new Exception();
            do $maxid = $row[$id_header];
            while ($row = mysqli_fetch_assoc($query));
        } catch (Exception $_) { $maxid = -1; }
        return array("max_id" => $maxid);
    }

    /**
     * Imprime el contenido un objeto JSON de forma válida para ser leído
     * @param $values Contenido de los datos a imprimir
     */
    public function echo ($values) {
        ob_clean();
        if (is_string($values)) $json = json_decode($values, true);
        elseif (is_bool($values)) $json = array("mysql-result" => ($values) ? "true" : "false");
        elseif (is_array($values) && array_keys($values) !== range(0, count($values) - 1)) $json = $values;
        elseif (is_object($values)) $json = $values;
        else throw new Exception("Invalid data format (" . gettype($values) . ")");
        header('Content-Type: application/json');
        echo json_encode((object)$json);
    }

    /**
     * Obtiene la información del servidor actual
     */
    public function serverinfo() {
        return json_encode((object)$_SERVER);
    }
}

?>