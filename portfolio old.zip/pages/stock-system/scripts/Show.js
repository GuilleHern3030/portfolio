import { connectDataBase as connect } from "./BasicDB.js";

const ID = 'id';

const className = classTitle => classTitle.trim().toLowerCase();

window.onload = async() => {

    let items = 0;

    const table = document.querySelector(".table-container");
    const emptyTable = document.querySelector(".table-empty");

    console.clear();

    const db = await connect("cfp33curso"); //const db = new DB("cfp33curso");
    db.setTable("usuarios");

    const allData = await db.readAll();
    console.table(allData);

    /*console.log(await db.isConnected());

    console.log("");
    console.log("readByIndex 3:")
    const readByIndex = await db.read(3);
    console.log(typeof(readByIndex));
    console.table(readByIndex);

    console.log("");
    console.log("readByInvalidIndex -2:")
    const readByInvalidIndex = await db.read(-2);
    console.log(typeof(readByInvalidIndex));
    console.table(readByInvalidIndex);

    console.log("");
    console.log("readByOutIndex 50:")
    const readByOutIndex = await db.read(50);
    console.log(typeof(readByOutIndex));
    console.table(readByOutIndex);

    console.log("");
    console.log("readByObject id:3 :")
    const readByObject = await db.read({"id":3});
    console.log(typeof(readByObject));
    console.table(readByObject);

    console.log("");
    console.log("invalidObject ggas:3 :")
    const readByInvalidObject = await db.read({"ggas":3});
    console.log(typeof(readByInvalidObject));
    console.table(readByInvalidObject);

    console.log("");
    console.log("outObject id:50 ")
    const readByOutObject = await db.read({"id":50});
    console.log(typeof(readByOutObject));
    console.table(readByOutObject);

    console.log("");
    console.log("serverInfo:")
    const serverInfo = await db.serverinfo();
    console.log(typeof(serverInfo));
    console.table(serverInfo);

    console.log("");
    console.log("maxid:")
    const maxid = await db.maxId();
    console.log(typeof(maxid));
    console.table(maxid);

    console.log("");
    console.log("maxindex:");
    const maxindex = await db.maxIndex();
    console.log(typeof(maxindex));
    console.table(maxindex);*/

    const headers = [];
    for (const index in allData) {
        items ++;
        for (const header in allData[index]) headers.push(header);
        break;
    }

    if (items > 0) {

        const fragment = document.createDocumentFragment();
        for (const header in headers) if (headers[header] !== ID){
            const paragraph = document.createElement("P");
            const textNode = document.createTextNode(`${headers[header]}`);
            paragraph.appendChild(textNode);
            fragment.appendChild(paragraph);
        }
        fragment.appendChild(document.createElement("P"));
        fragment.appendChild(document.createElement("P"));

        for (const index in allData) if (allData.hasOwnProperty(index)) {

            const id = allData[index][ID];

            //const tableDiv =  document.createElement("DIV");

            for (const header in allData[index]) if (header !== ID){
                const paragraph = document.createElement("P");
                const textNode = document.createTextNode(`${allData[index][header]}`);
                paragraph.classList.add(`${className(header)}-${id}`);
                paragraph.classList.add(`tableelement-${id}`);
                paragraph.appendChild(textNode);
                fragment.appendChild(paragraph);
            }

            const editButton = document.createElement("A");
            editButton.innerHTML = "Editar";
            editButton.classList.add(`editbutton`);
            editButton.classList.add(`tablebutton`);
            editButton.classList.add(`tableelement-${id}`);
            editButton.setAttribute("href", `producto_editar.html?${ID}=${id}`);
            fragment.appendChild(editButton);

            const deleteButton = document.createElement("BUTTON");
            deleteButton.innerHTML = "Borrar";
            deleteButton.classList.add(`deletebutton`);
            deleteButton.classList.add(`tablebutton`);
            deleteButton.classList.add(`tableelement-${id}`);
            //deleteButtonEvent(deleteButton, id);
            deleteButton.addEventListener("click", async () => {
                document.querySelectorAll(`.tableelement-${id}`).forEach(tableElement => {
                    tableElement.classList.remove(`tablebutton`);
                    tableElement.style.display = "none";
                });
        
                if (document.querySelector(".tablebutton") === null) {// no hay más botones
                    emptyTable.removeAttribute("hidden");
                    for (const htmlElement of table.children) {
                        if (!htmlElement.classList.contains("table-empty"))
                            htmlElement.style.display = "none";
                    }
                    //window.location.href = `producto_crear.html` // redirecciona la página
                }

                const json = {};
                json[ID] = id;
                const result = await db.remove(json);// USAR WEB WORKER
                console.log(result);
            });
            emptyTable.setAttribute("hidden", "");
            fragment.appendChild(deleteButton);

        };

        table.appendChild(fragment);

    }

    emptyTable.innerHTML = "No hay elementos que mostrar";

}