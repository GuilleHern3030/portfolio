const database = window.sessionStorage;

const STORAGE_DATA_PREFIX = "formstoragedata";

export class FormStorage {

    #inputs;
    #warningMessage;

    /**
     * Se buscarán todos los elementos con la clase "formstoragedata-input" para guardarlos como input
     * y el elemento con la clase "formstoragedata-submit" para guardarlo como botón de enviar.
     * Se debe asignar manualmente el addEventListener al botón enviar.
     */
    constructor() {
        this.#inputs = document.querySelectorAll(`.${STORAGE_DATA_PREFIX}-input`);
        this.submit = document.querySelector(`.${STORAGE_DATA_PREFIX}-submit`);
        this.#warningMessage = document.querySelector(`.${STORAGE_DATA_PREFIX}-warning`);
        if (this.#warningMessage !== null) this.#warningMessage.style.display = "none";
    }

    button() {
        return this.submit;
    }

    length() {
        database.length;
    }

    size() {
        let maxId = 0;
        try {
            const maxid = database.getItem(`${STORAGE_DATA_PREFIX}maxid`);
            maxId = (maxid !== null && typeof(maxid) !== NaN) ? parseInt(maxid) : 0;
        } catch (udf) { }
        return maxId;
    }

    getInputs() {
        return this.#inputs;
    }

    getInputsName() {
        let names = [];
        console.log("getInputsName");
        this.#inputs.forEach(input => { 
            console.log("El nombre de este input es " + input.name);
            names.push(input.name) 
        });
        return names;
    }

    getInput(i) {
        return this.#inputs[i];
    }

    getInputValue(i) {
        return this.#inputs[i].value;
    }

    getInputName(i) {
        return this.#inputs.name;
    }

    isInputFulled(i) {
        return (this.#inputs[i] != null 
            && this.#inputs[i] != undefined 
            && this.#inputs[i].value.length > 0);
    }

    isAllInputsFulled() {
        let fulled = true;
        this.#inputs.forEach(input => {
            if (!(input != null 
            && input != undefined 
            && input.value.length > 0)) {
                fulled = false;
                console.warn(`${input.name} no está lleno`);
            }
        });
        return fulled;
    }

    isAllRequiredInputsFulled() {
        let fulled = true;
        this.#inputs.forEach(input => {
            if (input.getAttribute("required") == "")
                if (!(input != null 
                && input != undefined 
                && input.value.length > 0)) {
                    fulled = false;
                    console.warn(`${input.name} no está lleno`);
                }
        });
        return fulled;
    }

    getStorage(id) {
        let dataStoraged = [];
        let i = 0;
        let data;
        while ((data = database.getItem(`${STORAGE_DATA_PREFIX}-${i}-${id}`)) !== null) {
            if (data !== NaN) dataStoraged.push(data);
            else dataStoraged.push(null);
            i ++;
        }
        return dataStoraged;
    }

    addStorage() {
        const newId = (this.size() + 1);
        this.setStorage(newId);
        database.setItem(`${STORAGE_DATA_PREFIX}maxid`, `${newId}`);
    }

    setStorage(id) {
        let i = 0;
        this.#inputs.forEach(input => {
            database.setItem(`${STORAGE_DATA_PREFIX}-${i}-${id}`, input.value);
            i ++;
        });
    }

    removeStorage(id) {
        let i = 0;
        while ((database.getItem(`${STORAGE_DATA_PREFIX}-${i}-${id}`)) !== null) {
            database.removeItem(`${STORAGE_DATA_PREFIX}-${i}-${id}`);
            i ++;
        }
    }

    clear() {
        database.clear();
    }

    /**
     * Si existe un elemento con la clase "formstoragedata-warning", 
     * se le cambiará el atributo display a 'block'
     */
    showWarningMessage() {
        if (this.#warningMessage !== null) this.#warningMessage.style.display = "block";
    }

    /**
     * Si existe un elemento con la clase "formstoragedata-warning", 
     * se le cambiará el atributo display a 'block'
     */
    hideWarningMessage() {
        if (this.#warningMessage !== null) this.#warningMessage.style.display = "none";
    }

    showStorageInConsole() {
        console.table(database);
    }

}