import { InputGetter } from "./InputGetter.js";
import { connectDataBase as connect } from "./BasicDB.js";

const inputs = new InputGetter();

const hide = (element) => element.classList.toggle("hidden", true);
const show = (element) => element.classList.remove("hidden");

window.onload = async () => {

    const db = await connect("cfp33curso");
    db.setTable("usuarios");

    const warnDiv = document.querySelector(".form-container__warningcontainer");

    const submitButton = document.getElementById("submit");
    document.querySelectorAll(".input").forEach(input => inputs.add(input));

    submitButton.addEventListener("click", async () => {
        if (inputs.isAllValid()) {
            hide(warnDiv);
            const result = await db.add(inputs.json());
            if (result) window.location.href = `producto_lista.html`;
            else submitButton.innerHTML = "Error";
        } else show(warnDiv);
    });

    submitButton.removeAttribute("disabled");
    submitButton.classList.toggle("form-container__button-disabled", false);
    submitButton.classList.toggle("form-container__button-enabled", true);
}