export class InputGetter{

    constructor () {
        this.length = 0;
    }

    #inputs = [];
    #type = [];
    #name = [];
    #required = [];
    #minLength = [];

    add(inputElement, type=undefined, required=undefined, name=undefined, minLength=undefined) {
        this.#inputs.push(inputElement);
        if (type === undefined) this.#type.push(inputElement.type); else this.#type.push(type);
        if (name === undefined) this.#name.push(inputElement.name); else this.#name.push(name);
        if (required === undefined) this.#required.push(inputElement.required); else this.#required.push(required);
        if (minLength === undefined) this.#minLength.push(inputElement.minLength); else this.#minLength.push(minLength);
        this.length += 1;
    }

    #getIndex = id => (isNaN(id)) ? this.#inputs.indexOf(id) : id;
    get = id => this.#inputs[this.#getIndex(id)];

    name = id => {
        const index = this.#getIndex(id);
        if (this.#name[index].length > 0) return this.#name[index];
    }

    forEach(aFunction) {
        this.#inputs.forEach(aFunction);
    }

    value(id) {
        const index = this.#getIndex(id);
        return this.#inputs[index].value;
    }

    json() {
        let obj = {};
        for (let id = 0; id < this.length; id++)
            obj[this.name(id)] = this.value(id);
        return obj;
    }

    isValid(id) {
        const index = this.#getIndex(id);
        if (this.#required[index] && this.#inputs[index].value.length <= 0) {
            console.warn(this.name(id) + ": is required but not have a value");
            return false;
        }
        if (this.#type[index] === "number" && isNaN(Number(this.#inputs[index].value))) {
            console.warn(this.name(id) + ": is number but has a NaN");
            return false;
        }
        if (this.#type[index] === "text" && this.#inputs[index].value.length < this.#minLength) {
            console.warn(this.name(id) + ": is number but not has sufficient letters");
            return false;
        }
        return true;
    }

    isAllValid() {
        for (let i = 0; i < this.length; i++)
            if (!this.isValid(i)) return false;
        return true;
    }
}