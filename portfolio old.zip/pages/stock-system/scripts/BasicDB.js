const DATABASE_MANAGER_URL = "scripts/database.php";

const MYSQL_KEY_SERVER = "mysql-servername";
const MYSQL_KEY_USER = "mysql-username";
const MYSQL_KEY_PASSWORD = "mysql-password";
const MYSQL_KEY_DBNAME = "mysql-dbname";
const MYSQL_KEY_TABLE = "mysql-tablename";

const stringify = str => (typeof str === 'string') ? str : "";
const isNumber = str => /^\d+$/.test(str);
const jsonParseNumbers = json => {
    if (typeof(json) === 'object') try { 
        for(const key in json)
            if (isNumber(json[key])) json[key] = Number(json[key]);
    } catch(err) { }
    return json;
}

const request = async (json={}, parameters="", responseIsJSON=true) => {
    try {
        return fetch(`${DATABASE_MANAGER_URL}?${parameters}`, {
        method: "POST",
        headers: { "Content-type" : "application/json" },
        body: JSON.stringify(json) })
        .then(response => (responseIsJSON) ? response.json() : response.text())
        .catch(err => err);
    } catch (err) { console.error("Error in request/fetch"); console.error(err); }
}

const fullRequest = async (json={}, parameters="", getter=undefined) => {
    return request(json, parameters)
    .then(result => {
        if (getter == undefined) return result;
        else if(result[getter] === 'true') return true;
        else if(result[getter] === 'false') return false;
        else if(isNumber(result[getter])) return Number(result[getter]);
        else return result[getter];
    })
    .catch(err => { 
        try { request(json, parameters, false).then(r => console.warn(r)); } catch(e) { }
        throw new Error(err); 
    });
}

/**
 * Establece la conexión a una base de datos
 * @param {string} dbname Nombre de la base de datos
 * @param {string} servername Nombre del servidor
 * @param {string} username Nombre de usuario
 * @param {string} password Contraseña del usuario
 * @returns {DataBase|IndexedDataBase} Devuelve la Base de Datos MySQL si se logra la conexión, o la IndexedDataBase en caso contrario
 */
export async function connectDataBase(dbname="", servername="localhost", username="root", password="") {
    let db = new DataBase(dbname, servername, username, password);
    let tryies = 0;
    try {
        const connected = await db.isConnected();
        if (connected == true || connected == "true") {
            console.log("Connected to MySQL");
            return db;
        } else throw new Error();
    } catch(err) {
        db = new IndexedDataBase(dbname, servername, username, password);
        while (tryies < 10) {
            await new Promise(resolve => setTimeout(resolve, 300));
            try { if (db.isConnected()) return db; } 
            catch(err) { tryies ++; }
        } throw new Exception("Not connected");
    }
}

export class DataBase {

    #servername;
    #username;
    #password;
    #dbname;
    #tablename;

    constructor (dbname="", servername="localhost", username="root", password="", tablename="") {
        this.#servername = stringify(servername);
        this.#username = stringify(username);
        this.#password = stringify(password);
        this.#dbname = stringify(dbname);
        this.#tablename = stringify(tablename);
    }

    /**
     * Establece qué tabla de la base de datos será trabajada
     * @param {string} $tablename Nombre de la tabla
     */
    setTable = tableName => this.#tablename = stringify(tableName);

    #json(jsonObject) {
        const serverInfo = {};
        if (this.#servername.length > 0) serverInfo[MYSQL_KEY_SERVER] = this.#servername;
        if (this.#username.length > 0) serverInfo[MYSQL_KEY_USER] = this.#username;
        if (this.#password.length > 0) serverInfo[MYSQL_KEY_PASSWORD] = this.#password;
        if (this.#dbname.length > 0) serverInfo[MYSQL_KEY_DBNAME] = this.#dbname;
        if (this.#tablename.length > 0) serverInfo[MYSQL_KEY_TABLE] = this.#tablename;
        return {...jsonObject, ...serverInfo};
    }

    /**
     * Verifica que la base de datos esté conectada (requiere await)
     * @returns {bool} Devuelve True si está conectado, False si no lo está
     */
    async isConnected() { // -> bool
        const connected = await fullRequest(this.#json({"mysql-operation": "isconnected"}), "", 'mysql-result');
        return connected;
    }

    /**
     * Obtiene la cantidad de filas válidas de la tabla (requiere await)
     * @returns {integer} Devuelve el número de filas
     */
    async maxIndex() { // -> int
        return fullRequest(this.#json({"mysql-operation": "maxindex"}), "", 'total_rows');
    }

    /**
     * Obtiene el id máximo de la tabla (requiere await)
     * @returns {integer} Devuelve el número de id máximo de la tabla
     */
    async maxId() { // -> int
        return fullRequest(this.#json({"mysql-operation": "maxid"}), "", 'max_id');
    }

    /**
     * Añadior una nueva fila a la tabla seleccionada (requiere await)
     * @param {jsonObject} jsonObject Información de la fila, por ejemplo, { "name" : "abc", ... }
     * @returns {bool} Devuelve True si se logró, False si no
     */
    async add(jsonObject) { // -> bool
        const operation = { "mysql-operation": "add" };
        return fullRequest(this.#json({...jsonObject, ...operation}), "", "mysql-result");
    }

    /**
     * Obtiene la información de una fila de la tabla seleccionada (requiere await)
     * @param {Number|jsonObject} index Selección del objeto a leer, por ejemplo, { "id" : "3" } selecciona la fila con id 3. Tener en cuenta que el primer index será el número 1.
     * @param {jsonObject} jsonObject Información de la fila, por ejemplo, { "name" : "abc", ... }
     * @returns {bool} Devuelve True si se logró, False si no
     */
    async edit(index, jsonObject) { // -> bool
        const operation = { "mysql-operation": "edit" };
        const newData = { "mysql-newdata": jsonObject };
        if (typeof index != 'object') index = { "mysql-index": index };
        return fullRequest(this.#json({...index, ...newData, ...operation}), "", "mysql-result");
    }

    /**
     * Obtiene la información de una fila de la tabla seleccionada (requiere await)
     * @param {Number|jsonObject} index Selección del objeto a leer, por ejemplo, { "id" : "3" } selecciona la fila con id 3. Tener en cuenta que el primer index será el número 1.
     * @returns {bool} Devuelve True si se logró, False si no
     */
    async remove(index) { // -> bool
        const operation = { "mysql-operation": "remove" };
        if (typeof index != 'object') index = { "mysql-index": index };
        return fullRequest(this.#json({...index, ...operation}), "", "mysql-result");
    }

    /**
     * Obtiene la información de una fila de la tabla seleccionada (requiere await)
     * @param {Number|jsonObject} index Selección del objeto a leer, por ejemplo, { "id" : "3" } selecciona la fila con id 3. Tener en cuenta que el primer index será el número 1.
     * @returns {object} Devuelve un objeto json con la información de la fila encontrada o un objeto con la key "error" en caso de fallar
     */
    async read(index) { // -> json object
        const operation = { "mysql-operation": "read" };
        if (typeof index != 'object') index = { "mysql-index": index };
        return fullRequest(this.#json({...index, ...operation}));
    }

    /**
     * Lee toda la tabla (requiere await)
     * @returns {object} Devuelve un objeto json con la inforamción de todas las filas de la tabla
     */
    async readAll() { // -> json object
        return fullRequest(this.#json({ "mysql-operation": "readall" }));
    }

    /**
     * Obtiene la información del servidor (requiere await)
     * @returns {object} Devuelve un objeto json con la inforamción del servidor
     */
    async serverinfo() { // -> json object
        return fullRequest(this.#json({ "mysql-operation": "serverinfo" }));
    }
}

const INDEXED_TABLE = "tables";
const INDEXED_ID = "id";
const INDEXED_MAX_ID = "_NEXT_ID_";
export class IndexedDataBase {

    #idb;
    #dbname;
    #servername;
    #username;
    #password;
    #tablename;
    #connected = false;

    constructor (dbname="indexeddb", servername="localhost", username="root", password="", tablename="") {
        this.#servername = stringify(servername);
        this.#username = stringify(username);
        this.#password = stringify(password);
        this.#dbname = stringify(dbname);
        this.#tablename = stringify(tablename);

        this.#idb = window.indexedDB.open(this.#dbname, 1);

        this.#idb.addEventListener("upgradeneeded", () => {
            this.#idb.result.createObjectStore(INDEXED_TABLE, { autoIncrement: true });
        });

        this.#idb.addEventListener("success", () => {
            this.#connected = true;
            console.log("Connected to IndexedDB");
        });
        this.#idb.addEventListener("error", () => { 
            console.error("DataBase not found.");
            this.#idb = null;
        });
    }

    /**
     * Establece qué tabla de la base de datos será trabajada
     * @param {string} $tablename Nombre de la tabla
     */
    setTable = async (tableName) => {
        this.#tablename = stringify(tableName);
        const table = this.#table(true);
        const cursor = table.openCursor();
        cursor.addEventListener("success", () => {
            if (cursor.result) {
                if (INDEXED_MAX_ID in cursor.result.value) return;
                cursor.result.continue();
            } else {
                const tableData = {}
                tableData[MYSQL_KEY_TABLE] = tableName;
                tableData[INDEXED_MAX_ID] = 1;
                table.add(tableData);
            }
        });
    }

    /**
     * Verifica que la indexeddb esté conectada
     * @returns {bool} Devuelve True si está conectado, False si no lo está
     */
    isConnected = () => this.#connected;

    #db = (writable=false) => this.#idb.result.transaction(INDEXED_TABLE, (writable) ? "readwrite" : "readonly");
    #table = (writable=false) => this.#db(writable).objectStore(INDEXED_TABLE);

    /**
     * Obtiene el id máximo de la tabla (requiere await)
     * @returns {integer} Devuelve el número de id máximo de la tabla
     */
    async maxId() { // -> int
        const table = this.#table();
        const cursor = table.openCursor();
        const ids = [];
        return await new Promise((resolve, reject) => {
            try {
                cursor.addEventListener("success", () => {
                    if (cursor.result) {
                        const json = cursor.result.value;
                        if (json[MYSQL_KEY_TABLE] === this.#tablename && INDEXED_ID in json)
                            ids.push(json[INDEXED_ID]);
                        cursor.result.continue();
                    } else return resolve((ids.length > 0) ? Math.max(...ids) : 0);
                });
            } catch (err) { return reject(err); }
        });
    }

    /**
     * Obtiene la cantidad de filas válidas de la tabla (requiere await)
     * @returns {integer} Devuelve el número de filas
     */
    async maxIndex() { // -> int
        const rows = await this.readAll();
        return rows.length;
    }

    /**
     * Añadior una nueva fila a la tabla seleccionada (requiere await)
     * @param {jsonObject} jsonObject Información de la fila, por ejemplo, { "name" : "abc", ... }
     * @returns {bool} Devuelve True si se logró, False si no
     */
    async add(jsonObject) { // -> bool
        jsonObject = jsonParseNumbers(jsonObject);
        const id = Number(await this.#getNextId());
        const json = await this.#json(jsonObject);
        json[INDEXED_ID] = id;
        const db = this.#db(true);
        this.#addNextId();
        this.#table(true).add(json);
        return await new Promise((resolve, reject) => {
            db.addEventListener("complete", () => resolve(true));
            db.addEventListener("onerror", () => reject(false));
        });
    }

    /**
     * Obtiene la información de una fila de la tabla seleccionada (requiere await)
     * @param {Number|jsonObject} index Selección del objeto a leer, por ejemplo, { "id" : "3" } selecciona la fila con id 3. Tener en cuenta que el primer index será el número 1.
     * @param {jsonObject} jsonObject Información de la fila, por ejemplo, { "name" : "abc", ... }
     * @returns {bool} Devuelve True si se logró, False si no
     */
    async edit(index, jsonObject) { // -> bool
        index = jsonParseNumbers(index);
        jsonObject = jsonParseNumbers(jsonObject);
        try {
            const key = await this.#getKey(index);
            const previousData = await this.read(index);
            if ('error' in previousData) return false;
            return await new Promise(resolve => {
                this.#table(true).put({...previousData , ...jsonObject }, key);
                this.#db(true).addEventListener("complete", () => resolve(true));
                this.#db(true).addEventListener("onerror", () => resolve(false));
            });
        } catch(err) { return false; }
    }

    /**
     * Obtiene la información de una fila de la tabla seleccionada (requiere await)
     * @param {Number|jsonObject} index Selección del objeto a leer, por ejemplo, { "id" : "3" } selecciona la fila con id 3. Tener en cuenta que el primer index será el número 1.
     * @returns {bool} Devuelve True si se logró, False si no
     */
    async remove(index) { // -> bool
        index = jsonParseNumbers(index);
        try {
            const key = await this.#getKey(index);
            return await new Promise(resolve => {
                this.#table(true).delete(key);
                this.#db(true).addEventListener("complete", () => resolve(true));
                this.#db(true).addEventListener("onerror", () => resolve(false));
            });
        } catch (err) { return false; }
    }

    /**
     * Obtiene la información de una fila de la tabla seleccionada (requiere await)
     * @param {Number|jsonObject} index Selección del objeto a leer, por ejemplo, { "id" : "3" } selecciona la fila con id 3. Tener en cuenta que el primer index será el número 1.
     * @returns {bool} Devuelve True si se logró, False si no
     */
    async read(index) {
        index = jsonParseNumbers(index);
        try {
            const key = await this.#getKey(index);
            const request = this.#table().get(key);
            return await new Promise((resolve, reject) => request.onsuccess = function(event) {
                if(event.target.result) return resolve(event.target.result);
                else throw new Error("Not found");
            });
        } catch (err) { return this.#error(err); }
    }

    /**
     * Lee toda la tabla (requiere await)
     * @returns {object} Devuelve un objeto json con la inforamción de todas las filas de la tabla
     */
    async readAll() {// -> json object
        const table = this.#table();
        const cursor = table.openCursor();
        const rows = [];
        return await new Promise((resolve, reject) => {
            try {
                cursor.addEventListener("success", () => {
                    if (cursor.result) {
                        const json = cursor.result.value;
                        if (json[MYSQL_KEY_TABLE] === this.#tablename && !(INDEXED_MAX_ID in json)) {
                            delete json[MYSQL_KEY_TABLE];
                            rows.push(json);
                        }
                        cursor.result.continue();
                    } else return resolve(rows);
                });
            } catch (err) { return reject(err); }
        });
    }

    /**
     * Obtiene la información del servidor (requiere await)
     * @returns {object} Devuelve un objeto json con la inforamción del servidor
     */
    async serverinfo() { // -> json object
        return { "server" : "indexeddb" };
    }

    async #getNextId() {
        const table = this.#table();
        const cursor = table.openCursor();
        return await new Promise((resolve, reject) => {
            cursor.addEventListener("success", () => {
                if (cursor.result) {
                    if (INDEXED_MAX_ID in cursor.result.value && cursor.result.value[MYSQL_KEY_TABLE] == this.#tablename) 
                        return resolve(Number(cursor.result.value[INDEXED_MAX_ID]));
                    cursor.result.continue();
                } else return resolve(1);
            });
        });
    }

    async #addNextId() {
        const newid = {};
        newid[MYSQL_KEY_TABLE] = this.#tablename;
        newid[INDEXED_MAX_ID] = 2;
        const table = this.#table(true);
        const cursor = table.openCursor();
        await new Promise((resolve, reject) => cursor.addEventListener("success", () => {
            if (cursor.result) {
                if (INDEXED_MAX_ID in cursor.result.value) {
                    newid[INDEXED_MAX_ID] = Number(cursor.result.value[INDEXED_MAX_ID]) + 1;
                    return resolve(table.put(newid, cursor.result.key));
                }
                cursor.result.continue();
            } else return resolve(table.add(newid));
        }));
    }

    async #getKey(index) {
        index = jsonParseNumbers(index);
        const table = this.#table();
        const cursor = table.openCursor();
        let i = 0;
        return await new Promise((resolve, reject) => cursor.addEventListener("success", () => {
            if (typeof(index) == 'number' && index <= 0) return reject("Invalid index");
            if (cursor.result) {
                const json = cursor.result.value;
                if (MYSQL_KEY_TABLE in json && json[MYSQL_KEY_TABLE] === this.#tablename) {
                    delete json[MYSQL_KEY_TABLE];
                    if (typeof(index) == 'number' && index === i) return resolve(cursor.result.key);
                    else if(typeof(index) !== 'number') {
                        let equal = true;
                        for (const key in index) {
                            try { if (json[key] !== index[key]) equal = false; }
                            catch(err) { equal = false; }
                        }
                        if (equal) return resolve(cursor.result.key);
                    } i++;
                }
                cursor.result.continue();
            } else return reject("Not found");
        }));
    }

    async #json(jsonObject) {
        jsonObject = jsonParseNumbers(jsonObject);
        const moreInfo = { };
        if (this.#tablename.length > 0) moreInfo[MYSQL_KEY_TABLE] = this.#tablename;
        return {...moreInfo ,...jsonObject};
    }

    #error = str => { return {"error" : str } };

}