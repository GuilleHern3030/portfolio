<?php

    include('conexion.php');

    $nombre_tabla = "productos";

    mysqli_query ($conexion, "ALTER TABLE $nombre_tabla AUTO_INCREMENT = 1"); // No funciona

    $peticion = mysqli_query($conexion, "SELECT * FROM productos");
    while ($resultado = mysqli_fetch_array($peticion)) {
        $id = $resultado['id'];
        mysqli_query ($conexion, "DELETE FROM $nombre_tabla WHERE id = '$id'");
    }

    // Lista de productos default de la ferretería 
    $productos = array(
        "Herramientas manuales" => array(
            "Martillo",
            "Destornillador",
            "Llave",
            "Alicate",
            "Llaves de Allen",
            "Sierra",
            "Cincel",
            "Limas",
            "Tijeras"
        ),
        "Herramientas eléctricas" => array(
            "Taladro",
            "Atornilladore eléctrico",
            "Sierra eléctrica",
            "Lijadora eléctrica",
            "Amoladora",
            "Pistola de calor",
            "Pulidora"
        ),
        "Equipos de protección personal" => array(
            "Casco de seguridad",
            "Guantes de trabajo",
            "Gafas de seguridad",
            "Máscara respiratoria",
            "Protectores auditivos",
            "Botas de seguridad"
        ),
        "Materiales de construcción" => array(
            "Cemento",
            "Pack de ladrillos",
            "Bloques de hormigón",
            "Varilla de acero",
            "Adhesivos y pegamentos",
            "Arena",
            "Grava",
            "Yeso",
            "Pinturas"
        ),
        "Cerrajería y seguridad" => array(
            "Cerradura",
            "Candado",
            "Bisagra",
            "Mirilla",
        ),
        "Fontanería" => array(
            "Tubería",
            "Válvula",
            "Grifo y llave de paso",
            "Sifone",
            "Cisterna",
            "Bomba de agua",
            "Calentador de agua"
        ),
        "Electricidad" => array(
            "Cable eléctrico",
            "Tomacorriente",
            "Interruptor",
            "Fusible",
            "Bombilla",
            "Panel eléctrico"
        ),
        "Jardinería" => array(
            "Manguera de riego",
            "Aspersor",
            "Fertilizante",
            "Maceta jardinera"
        )
    );
    
    // Acceder a los productos de "Herramientas manuales"
    //$herramientasManuales = $productos["Herramientas manuales"];
    //echo "Productos de Herramientas manuales: " . implode(", ", $herramientasManuales);

    foreach ($productos as $categoria => $productosCategoria) {
        foreach ($productosCategoria as $producto) {
            $cantidad_aleatoria = random_int(0, 7);
            $validacion = mysqli_query ($conexion, "INSERT INTO $nombre_tabla (nombre, descripcion, cantidad) VALUE ('$producto','Stanley', '$cantidad_aleatoria')");
            $cantidad_aleatoria = random_int(0, 7);
            $validacion = mysqli_query ($conexion, "INSERT INTO $nombre_tabla (nombre, descripcion, cantidad) VALUE ('$producto','Knipex', '$cantidad_aleatoria')");
        }
    }

    header('Location: index.php');
?>