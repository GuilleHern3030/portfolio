<?php

    if ($_GET && isset($_GET['id'])) {

        $nombre_tabla = "productos";

        $id = $_GET['id'];
        $nombre = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $cantidad = $_POST['cantidad'];

        if (strlen($nombre) > 0 && strlen($descripcion) > 0) {

            include('conexion.php');

            $query = "UPDATE $nombre_tabla SET nombre = '$nombre', descripcion = '$descripcion', cantidad = '$cantidad' WHERE id = '$id'";

            $validacion = mysqli_query ($conexion, $query);

            if ($validacion) header('Location: producto_editar.php?success=1');
            else header('Location: producto_editar.php?success=0');

        } else header('Location: producto_editar.php?success=2');
    
    } else header('Location: producto_lista.php');

?>