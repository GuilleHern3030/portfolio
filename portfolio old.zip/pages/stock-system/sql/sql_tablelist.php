
<?php
    $peticion = mysqli_query($conexion, "SELECT * FROM productos");
    $resultado = mysqli_fetch_array($peticion);
    if($resultado != null) {
    ?>
    <table>
        <tr>
            <td>ID producto</td>
            <td>Nombre</td>
            <td>Descripción</td>
            <td>Cantidad</td>
            <td>Fecha de Ingreso</td>
        </tr>
        <?php do { ?>
            <tr>
                <td><?php echo $resultado['id']?></td>
                <td><?php echo $resultado['nombre']?></td>
                <td><?php echo $resultado['descripcion']?></td>
                <td><?php echo $resultado['cantidad']?></td>
                <td><?php echo $resultado['fecha_ingreso']?></td>
                <td><a href=<?php print 'producto_editar.php?id=' . $resultado['id']?>>Editar</a></td>
                <td><a href=<?php print 'sql_delete.php?id=' . $resultado['id']?>>Eliminar</a></td>
            </tr>
            <?php
            } while ($resultado = mysqli_fetch_array($peticion));
        ?>
    </table>
    <?php 
    } else {
    ?>

    <p>Aún no existen productos listados</p>

    <?php } ?>