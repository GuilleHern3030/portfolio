<?php

    $nombre_tabla = "productos";

    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $cantidad = $_POST['cantidad'];

        /*$nombre = trim($nombre);
        $nombre = htmlspecialchars($nombre);
        $nombre = stripslashes($nombre);*/

    if (!empty($nombre) && strlen($descripcion) > 0) {
        
        include('conexion.php');
      
        $guardar = "INSERT INTO $nombre_tabla (nombre, descripcion, cantidad) VALUE ('$nombre','$descripcion','$cantidad')";
        
        $validacion = mysqli_query ($conexion,$guardar);

        if ($validacion) header('Location: producto_crear.php?success=1');
        else header('Location: producto_crear.php?success=0');

    } else header('Location: producto_crear.php?success=2');

?>