<?php

    try {

        $conexion = mysqli_connect('localhost','root','','almacen');

    } catch (Exception $e) { 

        echo "No se pudo conectar con la base de datos.\n\n";
        ?>
        <form class="contacto" action="index.php">
            <input type="submit" action="index.php" value="Volver al inicio">
        </form>
        <?php
        die();
        
    }
    
?>