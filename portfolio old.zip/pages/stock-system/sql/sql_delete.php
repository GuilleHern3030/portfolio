<?php

    if ($_GET && isset($_GET['id'])) {

        include('conexion.php');

        $nombre_tabla = "productos";

        $id = $_GET['id'];
        $nombre = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $cantidad = $_POST['cantidad'];

        $query = "DELETE FROM $nombre_tabla WHERE id = '$id'";

        $validacion = mysqli_query ($conexion, $query);

        if ($validacion) header('Location: producto_lista.php?success=1');
        else header('Location: producto_lista.php?success=0');
    
    } else header('Location: producto_lista.php?success=0');

?>