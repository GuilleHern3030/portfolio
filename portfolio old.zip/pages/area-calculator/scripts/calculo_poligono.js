const calcularArea = (datos) => {
    let cantidadLados = datos[0];
    let longitudLado = datos[1];
    return calculoAreaPoligono(longitudLado, cantidadLados);
}

const calcularApotema = (longitudLado, cantidadLados) => {

    return (longitudLado / (2 * Math.tan(Math.PI / cantidadLados)));


    let angulo = Math.PI / cantidadLados;
    let tangente = Math.tan(angulo);
    let apotema = longitudLado / (2 * tangente);
    return apotema;
}

const calculoAreaPoligono = (longitudLado, cantidadLados) => {
    let apotema = calcularApotema(longitudLado, cantidadLados);
    return longitudLado * cantidadLados * (longitudLado / 2 * Math.tan(Math.PI / cantidadLados)) / 2; 
}