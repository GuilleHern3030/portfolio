const calcularArea = (datos) => {
    let cantidadLados = 5;
    let longitudLado = datos[0];
    return calculoAreaPoligono(longitudLado, cantidadLados);
}

const calcularApotema = (longitudLado, cantidadLados) => {
    let angulo = Math.PI / cantidadLados;
    let tangente = Math.tan(angulo);
    let apotema = longitudLado / (2 * tangente);
    return apotema;
}

const calculoAreaPoligono = (longitudLado, cantidadLados) => {
    let apotema = calcularApotema(longitudLado, cantidadLados);
    return longitudLado * cantidadLados * apotema / 2; 
}