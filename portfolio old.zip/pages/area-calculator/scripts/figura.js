window.onload = () => {
    
    // Elementos HTML
    const boton = document.getElementById("calculate-btn");
    const campos = document.querySelectorAll(".input");
    const pResultado = document.getElementById("result");

    // Nombre de la figura
    const figura = (window.location.pathname.split('/').pop()).split('.')[0];
    //(document.getElementById("figura-img")).setAttribute("src", `${figura}.png`);
    (document.getElementById("legend")).textContent = `Cálculo de un ${figura}`;

    // Evento del botón de calcular área
    boton.addEventListener("click", () => {
        const datos = obtenerDatos();
        if (datos != null) {
            const resultado = calcularAreaGeometrica(figura, datos);
            mostrarResultado(resultado);
        } else pedirLlenarDatos();
    });

    // Obtener los datos de los campos
    const obtenerDatos = () => {
        let datos = [];
        let existeCampoVacio = false;

        let index = 0;
        campos.forEach(campo => {
            if(campo.value.length == 0)
                existeCampoVacio = true;
            datos[index] = Math.abs(parseInt(campo.value));
            index ++;
        });

        return (existeCampoVacio) ? null : datos;
    }

    // Calculo del área
    const calcularAreaGeometrica = (figura, datos) => {
        switch (figura) {
            case 'cilindro': return 2 * Math.PI * datos[0] * (datos[1] + datos[0]);
            case 'circulo': return datos[0] * Math.PI * Math.PI;
            case 'cuadrado': return datos[0] * datos[0];
            case 'cubo': return datos[0] * datos[0] * 6;
            case 'hexagono': return calcularAreaGeometrica("poligono", [6, datos[0]]);
            case 'pentagono': return calcularAreaGeometrica("poligono", [5, datos[0]]);
            case 'poligono': return datos[1] * datos[0] * (datos[1] / (2 * Math.tan(Math.PI / datos[0]))) / 2;
            case 'rectangulo': return datos[0] * datos[1];
            case 'rombo': return datos[0] * datos[1] / 2;
            case 'romboide': return datos[0] * datos[1];
            case 'tetraedro': return datos[0] * datos[0] * Math.pow(3 , 1/2);
            case 'trapecio': return (datos[0] + datos[1]) * datos[2] / 2;
            case 'triangulo': return datos[0] * datos[1] / 2;
            default: return "Se desconoce cómo calcular esta figura";
        }
    }

    // Mostrar resultado obtenido del cálculo de área
    const mostrarResultado = resultado => {
        pResultado.textContent = `Area: ${resultado}`;
        pResultado.style.color = "#000000"
        pResultado.style.display = "block";
    }

    // Pedir que se llenen los campos sin datos
    const pedirLlenarDatos = () => {
        pResultado.textContent = `Debes llenar todos los datos con números válidos para poder calcular el área del ${figura}`;
        pResultado.style.display = "block";
        pResultado.style.color = "#ffeeee"
    }

}