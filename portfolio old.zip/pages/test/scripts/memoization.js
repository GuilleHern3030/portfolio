

const cache = [];
const memoizer = func => {
    return e => {
        const index = e.toString();
        if (cache[index] === undefined)
            cache[index] = func(e);
        return cache[index];
    }
}

// Definimos la función larga
function funcionLarga(...params) {
    // proceso que demorará en finalizar
}

// Definimos la función dentro del memoizer
const memo = memoizer(funcionLarga);

// Ejecutamos la función desde el memoizer
memo(parametros);

