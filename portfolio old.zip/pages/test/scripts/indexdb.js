"use strict";
  
// Crear (o abrir) una Base de Datos         nombre  , version
const IDBrequest = window.indexedDB.open("myDataBase",    1    );

IDBrequest.addEventListener("upgradeneeded", () => {
    const db = IDBrequest.result; // Data Base
    db.createObjectStore("nombres", { // Crear una 'Tabla' llamada "nombres"
        autoIncrement: true // key que se autoincrementa cada vez que se agrega algo
    });
});

IDBrequest.addEventListener("success", () => console.log("Abierto correctamente"));
IDBrequest.addEventListener("error", () => console.log("Ocurrió un error"));

const addObject = object => {
    const db = IDBrequest.result; // DataBase
    const IDBtransaction = db.transaction("nombres", "readwrite");
    const objectStore = IDBtransaction.objectStore("nombres");
    objectStore.add(object);
    IDBtransaction.addEventListener("complete", () => {
        console.log("Se ha añadido el objeto");
    });
}

const readObjects = () => {
    const db = IDBrequest.result; // DataBase
    const IDBtransaction = db.transaction("myDataBase", "readonly");
    const objectStore = IDBtransaction.objectStore("nombres");
    const cursor = objectStore.openCursor();
    cursor.addEventListener("success", () => {
        if (cursor.result) {
            console.log(cursor.result.value); // Muestra el objeto leído
            cursor.result.continue(); // Lee el siguiente objeto
        } else {
            // Una vez que termine de leer todo, ejecuta este bloque
            console.log("Todos los datos fueron leídos");
        }
    });
}

// Si el objeto ya existe, lo modifica
// Si el objeto no existe, lo crea
const editObject = (key, object) => {
    const db = IDBrequest.result; // DataBase
    const IDBtransaction = db.transaction("myDataBase", "readwrite");
    const objectStore = IDBtransaction.objectStore("nombres");
    objectStore.put(object, key);
    IDBtransaction.addEventListener("complete", () => {
        console.log("Se ha modificado el objeto");
    });
}

const deleteObject = key => {
    const db = IDBrequest.result; // DataBase
    const IDBtransaction = db.transaction("myDataBase", "readwrite");
    const objectStore = IDBtransaction.objectStore("nombres");
    objectStore.add(key);
    IDBtransaction.addEventListener("complete", () => {
        console.log("Se ha eliminado el objeto");
    });
}

setTimeout(() => {
    addObject({"Asd": "Hola"});
}, 300);