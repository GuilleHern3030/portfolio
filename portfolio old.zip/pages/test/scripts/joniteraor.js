let division = 0;
const divs = document.querySelectorAll(".div");


const print = (element) => {
    console.log(element);
    divs[division].appendChild(paragraph(element));
}

const paragraph = (text="", className) => {
    const _paragraph = document.createElement("P");
    const _textNode = document.createTextNode(text);
    if (className) _paragraph.classList.add(className);
    _paragraph.appendChild(_textNode);
    return _paragraph;
}

/*const jsonObject = {
    name: "Guillermo",
    age: 29,
    married: true,
    points: [10, 2, 5, 6],
    direction: { streetName: "Av. Mitre", streetNumber: 2010 }
}*/

const jsonObject = {
    "name": "Guillermo",
    "age": 29,
    "married": true,
    "points": [10, 2, 5, 6],
    "direction": { streetName: "Av. Mitre", streetNumber: 2010 }
}

console.log(jsonObject.length); // undefined

console.table(jsonObject);

division = 0; // for each
try {

jsonObject.forEach(element => {
    print(element);
});// ERROR: Is not a function 

} catch(e) { print(e.toString()) }





division = 1; // for 
try {

for (let index = 0; index < jsonObject.length; index++) {
    const value = jsonObject[index]; // do nothing
    print(value);
}
// jsonObject.length is undefined

} catch(e) { print(e.toString()) }





division = 2; // for in
try {

for (const key in jsonObject) {
    const value = jsonObject[key];
    print(value);
}

} catch(e) { print(e.toString()) }





division = 3; // for of
try {

for (const index of jsonObject) {
    // ERROR: jsonObject is not iterable
}

} catch(e) { print(e.toString()) }





division = 4; // Object.keys
try {

const keys = Object.keys(jsonObject);
keys.forEach(key => {
    const value = jsonObject[key];
    print(value);
})

} catch(e) { print(e.toString()) }





division = 5; // Object.values
try {

const values = Object.values(jsonObject);
values.forEach(value => { // no key
    print(value);
})

} catch(e) { print(e.toString()) }






division = 6; // Object.entries
try {

Object.entries(jsonObject).forEach(([key, value]) => {
    print(key + ": " + value);
});

} catch(e) { print(e.toString()) }