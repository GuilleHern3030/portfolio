
const htmlElements = document.querySelectorAll(".caja");

const verifyVisibility = entries => { // entries es un array
    for (const entry of entries) {

         // isIntersecting es true cuando el elemento se visualiza
        if (entry.isIntersecting) {
            const element = entry.target;
            console.log(element.textContent);
        }

    }
}

const options = { // es un objeto
    rootMargin: "30px" // Detectará el htmlElement 30 píxeles antes
}

const observer = new IntersectionObserver(verifyVisibility, options);

for (const caja of htmlElements) {
    observer.observe(caja); // Observa el html element
}

