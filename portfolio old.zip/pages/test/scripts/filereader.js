const params = new Proxy(new URLSearchParams(window.location.search), {
    get: (searchParams, prop) => searchParams.get(prop)
});

const paramName = params.name;
const paramAmount = params.amount;
const paramText = params.textarea;

/*console.log(paramName);
console.log(paramAmount);
console.log(paramText);*/


const colorDragableZone = (element, inZone) => {
    if (inZone) {
        element.style.color = "#4c3688";
        element.style.border = `4px dashed #4c3688`;
        element.style.backgroundColor = "#c0bfbf";
        element.innerText = "Ya puede soltar el archivo";
    } else {
        element.style.color = "#6e52bb";
        element.style.border = `4px dashed #6e52bb`;
        element.style.backgroundColor = "#e8e8e8";
        element.innerText = "Arrastre un archivo aquí";
    }
}

const zonaArrastre = document.querySelector(".zona-arrastre");
zonaArrastre.addEventListener("dragleave", e => colorDragableZone(e.target, false));
zonaArrastre.addEventListener("dragenter", e => colorDragableZone(e.target, true));
zonaArrastre.addEventListener("dragover", e => e.preventDefault()); // Habilitar drop
zonaArrastre.addEventListener("drop", e => {
    e.preventDefault(); // Deshabilita que el archivo se abra en otra pestaña
    colorDragableZone(e.target, false);
    const archivoArrastrado = e.dataTransfer.files[0];
    cargarArchivo(archivoArrastrado);
});

const cargarArchivo = file => {
    const reader = new FileReader();
    reader.readAsArrayBuffer(file);

    reader.addEventListener("progress", e=>{ // Se ejecuta cada 4% de archivo cargado
        //console.log(`${e.loaded} cargado de ${e.total}`); // En numeros absoultos
        console.log(`${(e.loaded * 100 / e.total).toFixed(0)}%`); // En porcentaje sin decimales
    });

    reader.addEventListener("load", e => {

        // Cargamos el video a un formato valido
        const videoBlob = 
            new Blob([new Uint8Array(e.currentTarget.result)], {type: "video/mp4"});
        const url = URL.createObjectURL(videoBlob);

        // En caso de que sea una imagen:
        const video = document.createElement("VIDEO"); 
        video.setAttribute("src", url);

        // Pega la imagen en el body
        document.getElementsByTagName("body")[0].appendChild(video);
        
        video.play(); // Reproduce el video
    });
}


/*window.onload = () => {
    const bSubmit = document.getElementById("submit");
    const inputName = document.getElementById("input-name");
    const inputAmount = document.getElementById("input-amount");
    const inputTextArea = document.getElementById("input-text");
    const warnDiv = document.querySelector(".form-container__warningcontainer");

    bSubmit.addEventListener("click", () => {
        if (inputName.value.length > 0 
        && inputAmount.value.length > 0
        && inputTextArea.value.length > 0) {
            warnDiv.classList.toggle("hide", true);// Oculta el aviso

            // CODE

        } else warnDiv.classList.remove("hide");// Muestra el aviso
    });

    const inputFile = document.getElementById("input-file");
    const imagesContainer = document.querySelector(".images-container");

    inputFile.addEventListener("change", () => {
        // Obtener todos los archivos seleccionados
        const files = inputFile.files; 
        readFile(files);
    });

    const readFile = files => {
        for (let file of files) {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.addEventListener("load" , progressEvent => { 
                const result = progressEvent.currentTarget.result;
                const newImage = `<img src=${result}>`;
                imagesContainer.innerHTML += newImage;
            });
        }
    }


}*/




//colorDragableZone(zonaArrastre, false);