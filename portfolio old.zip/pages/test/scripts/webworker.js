

// Dedicated worker
const worker = new Worker("")