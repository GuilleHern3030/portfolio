instrucciones = """
 * Para utilizar esta class, es necesario instanciarla con la SEED con la cual se trabajará
 * Funciones disponibles:
    - encryptFile: ecrypta un archivo de texto y lo guarda en un archivo encriptado
    - decryptFile: desencripta un archivo encriptado y lo guarda en un archivo de texto
    - encryptText: encripta un texto y lo guarda como lista en '__cryptography__'
        -> getEncryptedText: devuelve la lista '__cryptography__'
    - decryptText: desencripta un texto y lo guarda como lista en '__decryptography__'
        -> getDecryptedText: devuelve la lista '__decryptography__'
    - getText: devuelve el lista '__decryptography__' convertido a texto
    - clear: borra el contenido de las listas '__cryptography__' y '__decryptography__'
    - setEmptyCharacterFrequencyRange: establece el rango entre espacios vacíos de la encriptación
    - stopEncrypting: detiene el proceso de encriptado"""

from random import randint

# Constantes personalizables
DEFAULT_FOLDER_NAME = "cryptography"
FILE_EXTENDS = "cpt"

# Constantes no personalizables
CC_START = 30
CC_NL = 31
CC_NULL = 30
MAX_CHARACTERS = 24
RECOMENDED_MAX_LENGTH = 300000

def __getC__(p:str) -> list:
    if len(p) > MAX_CHARACTERS:
        p = p[0:(MAX_CHARACTERS+1)]
    c = []
    p = str(p)
    for i in range(MAX_CHARACTERS):
        if i < len(p):
            c.append(int(str(oct(int(ord(str(p[i])))))[2:]))
        else:
            try:
                c.append(int(str(oct(int(c[i-len(p)])))[2:]))
            except:
                c.append(int(str(oct(int(len(p))))[2:]))
    return c

def __getD__(c: list, length:int) -> list:
    d = []
    for x in range(MAX_CHARACTERS):
        d.append(int(0))
    tmp = 0
    l = int(length)
    if length == 0:
        l = MAX_CHARACTERS
    for x in range(MAX_CHARACTERS):
        tmp = int(x)
        try:
            if x == 0: tmp = (l-1)
            elif x == 1: tmp = (l+1)
            elif x == 2: tmp = ((l+13)//l)
            elif x == 3: tmp = (c[5]//(l*l+(l//2)))
            elif x == 4: tmp = d[2]+d[3]
            elif x == 5: tmp = d[6]-d[1]
            elif x == 6: tmp = c[23]//d[0]
            elif x == 7: tmp = c[21]-c[12]
            elif x == 8: tmp = c[10]*l//c[2]
            elif x == 9: tmp = l-c[17]+d[10]
            elif x == 10: tmp = d[4]*l
            elif x == 11: tmp = l+5+d[7]
            elif x == 12: tmp = c[2]-c[6]+d[4]
            elif x == 13: tmp = d[8]-c[7]
            elif x == 14: tmp = c[15]-c[16]
            elif x == 15: tmp = d[5]-d[16]
            elif x == 16: tmp = c[20]//l
            elif x == 17: tmp = d[18]//d[16]
            elif x == 18: tmp = d[13]*d[19]//d[16]
            elif x == 19: tmp = d[17]+l+(d[19]*d[0])
            elif x == 20: tmp = c[7]//l
            elif x == 21: tmp = c[15]//d[22]
            elif x == 22: tmp = c[11]+l-d[14]//c[6]
            elif x == 23: tmp = d[1]//c[3]+l
            else: tmp += (d[(x-8)]*c[x-4] // length)
        except: tmp = length
        if tmp == 0: 
            tmp = int(str(oct(int(length+x)))[2:]) 
        if tmp < 0: tmp *= -1
        d[x] = tmp
    return d

def __getSO__(c: list, length:int) -> int:
    so = 1
    for i in range(length):
        so += (int(str(oct(int(c[i])))[2:]) * (i+11))
    return so

def __getMaxCharId__(text: str) -> int:
    maxChar = 0
    try:
        text = str(text)
        if len(text) > 0:
            for l in text:
                if ord(l) > maxChar:
                    maxChar = ord(l)
            maxChar += randint(0, MAX_CHARACTERS)
    except:
        maxChar = 255
    return maxChar

def __parseCharToCryptoChar__(charr: str) -> int:
    crch = 63 # ?
    if charr == "":
        crch = CC_NULL
    elif charr == "\n":
        crch = CC_NL
    elif len(charr) == 1:
        try:
            crch = ord(charr)
        except:
            None
    return crch

def __parseCryptoCharToString__(l: int) -> str:
    charr = None
    if l == CC_NL:
        charr = "\n"
    elif l == CC_NULL:
        charr = ""
    else:
        charr = chr(l)
    return charr

def __getSmallFromDouble__(integer: int, CryptoCharLimit: int, CC_START: int) -> int:
    while integer > CryptoCharLimit:
        integer -= CryptoCharLimit
    if integer < CC_START:
        integer = (integer*(CryptoCharLimit-CC_START)/CC_START)+CC_START
    return int(integer)

def log(text: str) -> None:
    if __name__  == "__main__":
        print(str(text), end="")

class Cryptography:

    def __init__(self, seed: str = "1234"):
        self.__textEncrypted__ = None
        self.__encrypting__ = False
        self.__textDecrypted__ = None
        self.frequencyRangeNullMin = 3
        self.frequencyRangeNullMax = 12
        self.__c__ = __getC__(str(seed))
        self.__d__ = __getD__(self.__c__, len(seed))
        self.__so__ = __getSO__(self.__c__, len(seed))

    def __encryptChar__(self, character:str, iteration:int, ccLimit:int, falseEncrypt:bool) -> int:
        crypto = -1
        c = self.__c__
        d = self.__d__
        so = self.__so__
        if len(character) == 1:
            i = iteration
            x = int(iteration%len(c))
            y = int(iteration//len(c))%len(c)
            z = int((iteration//len(c))//len(c))
            soi = ((so+iteration)*(z+ccLimit))*int(c[x])//int(d[y])
            if soi < 0:
                soi *= -1
            tmp = 0
            cryptoChar = __parseCharToCryptoChar__(character)
            while (not falseEncrypt and tmp != cryptoChar) or (falseEncrypt and tmp != CC_NULL):
                crypto += 1
                integer = ((soi)*c[y]//d[x] + crypto) % ccLimit
                if integer < CC_START: integer = (integer*(ccLimit-CC_START)//CC_START)+CC_START
                tmp = int(integer)
                if crypto > ccLimit: 
                    print("[ERROR ec]", character, str(ccLimit), str(falseEncrypt))
                    break
        return crypto

    def __decryptChar__(self, cryptoChar:int, iteration:int, ccLimit:int) -> int:
        c = self.__c__
        d = self.__d__
        so = self.__so__
        x = int(iteration%len(c))
        y = int(iteration//len(c))%len(c)
        z = int((iteration//len(c))//len(c))
        soi = ((so+iteration)*(z+ccLimit))*int(c[x])//int(d[y])
        if soi < 0:
            soi *= -1
        integer = ((soi)*c[y]//d[x] + cryptoChar) % ccLimit
        if integer < CC_START: integer = (integer*(ccLimit-CC_START)//CC_START)+CC_START
        return int(integer)
    
    def __decryptCharAndParse__(self, cryptoChar:int, iteration:int, ccLimit:int) -> str:
        _cryptoChar = self.__decryptChar__(cryptoChar, iteration, ccLimit)
        return __parseCryptoCharToString__(_cryptoChar)

    def stopEncrypting(self):
        self.__encrypting__ = False
        
    def getEncryptedText(self) -> list:
        if self.__textEncrypted__ != None:
            return self.__textEncrypted__
        else:
            return []
        
    def getDecryptedText(self) -> str:
        return self.__textDecrypted__

    def clear(self) -> None:
        self.__textEncrypted__ = None
        self.__textDecrypted__ = ""
    
    def setEmptyCharacterFrequencyRange(self, frequencyMin:int, frequencyMax:int):
        if(frequencyMax < 0): frequencyMax *= -1
        if(frequencyMin < 0): frequencyMax *= -1
        if(frequencyMax >= frequencyMin):
            self.frequencyRangeNullMax = frequencyMax
            self.frequencyRangeNullMin = frequencyMin
        else:
            self.frequencyRangeNullMax = frequencyMin
            self.frequencyRangeNullMin = frequencyMax

    def decryptText(self, encryptText:list = []) -> str:
        if str(type(encryptText)).find("list") == -1 or (str(type(encryptText)).find("list") >= 0 and len(encryptText) <= 1):
            encryptText = self.__textEncrypted__
            log("Text encrypted designed in the recently encrypted\n")
        try:
            log("Decrypting text... ")
            ccLimit = encryptText[0]
            self.__encrypting__ = True
            self.__textDecrypted__ = ""
            i = 1
            while self.__encrypting__ and i < len(encryptText):
                self.__textDecrypted__ += self.__decryptCharAndParse__(int(encryptText[i]), i, ccLimit)
                i += 1
            log("finished.\n")
        except:
            log("failed.\n")
        self.__encrypting__ = False
        return self.__textDecrypted__

    def encryptText(self, text:str) -> list:
        try:
            log("Encrypting text... ")
            text = str(text)
            self.clear()
            self.__encrypting__ = True
            self.__textEncrypted__ = []
            ecfmax = self.frequencyRangeNullMax
            ecfmin = self.frequencyRangeNullMin
            ccLimit = __getMaxCharId__(text)
            (self.__textEncrypted__).append(ccLimit)
            r = randint(ecfmin, ecfmax) - ecfmin
            chr = 0
            iteration = 1
            while self.__encrypting__ and chr < len(text):
                if r >= ecfmax:
                    (self.__textEncrypted__).append(self.__encryptChar__(str(text[chr]), iteration, ccLimit, False))
                    r = randint(ecfmin, ecfmax) - ecfmin
                    chr += 1
                else:
                    (self.__textEncrypted__).append(self.__encryptChar__(str(text[chr]), iteration, ccLimit, True))
                    r += 1
                iteration += 1
            log("finished.\n")
        except:
            log("failed.\n")
        self.__encrypting__ = False
        return self.getEncryptedText()

    def encryptFile(self, textFilePath:str, fileEncryptedPath:str) -> bool:
        fileEncryptedSuccessfull = True
        self.__encrypting__ = True
        ecfmax = self.frequencyRangeNullMax
        ecfmin = self.frequencyRangeNullMin
        try:
            log("Encrypting file... ")
            textFile = open(str(textFilePath))
            ccLimit = CC_NL
            iteration = 1
            chr = 0
            r = randint(ecfmin, ecfmax) - ecfmin
            for linea in textFile.readlines():
                _ccLimit = __getMaxCharId__(linea)
                if ccLimit < _ccLimit:
                    ccLimit = _ccLimit 
            encryptedFile = open(str(fileEncryptedPath), "w")
            encryptedFile.write(str(ccLimit))
            textFile.seek(0)
            for text in textFile.readlines():
                for character in text:
                    if self.__encrypting__:
                        while r < ecfmax:
                            encoded = self.__encryptChar__(str(character), iteration, ccLimit, True)
                            encryptedFile.write("\n" + str(encoded))
                            iteration += 1
                            r += 1
                        encoded = self.__encryptChar__(str(character), iteration, ccLimit, False)
                        encryptedFile.write("\n" + str(encoded))
                        r = randint(ecfmin, ecfmax) - ecfmin
                        iteration += 1
                    else:
                        break
            log("finished.\n")
            textFile.close()
            encryptedFile.flush()
            encryptedFile.close()
        except:
            log("failed.\nFile not found or is impossible to access.")
            fileEncryptedSuccessfull = False
        self.__encrypting__ = False
        return fileEncryptedSuccessfull
    
    def decryptFile(self, fileEncryptedPath:str, fileDecryptedPath:str) -> bool:
        fileEncryptedSuccessfull = True
        self.__encrypting__ = True
        try:
            log("Decrypting file... ")
            encryptedFile = open(str(fileEncryptedPath))
            decryptedFile = open(str(fileDecryptedPath), "w")
            ccLimit = 0
            iteration = 0
            for cchar in encryptedFile.readlines():
                cchar = int(cchar)
                if iteration == 0:
                    ccLimit = int(cchar)
                else:
                    character = self.__decryptCharAndParse__(int(cchar), iteration, ccLimit)
                    try: 
                        decryptedFile.write(str(character)) 
                    except:
                        pass
                iteration += 1
            log("finished.\n")
        except:
            log("failed.\nFile not found or is impossible to access.")
            fileEncryptedSuccessfull = False
        self.__encrypting__ = False
        return fileEncryptedSuccessfull

    def saveEncryptedTextInFile(self, encryptedText:list = [], filePath:str = "") -> None:
        if str(type(encryptedText)).find("list") == -1 or (str(type(encryptedText)).find("list") >= 0 and len(encryptedText) <= 1):
            encryptedText = self.__textEncrypted__
            log("Text encrypted designed in the recently encrypted\n")
        file = open(filePath, "w")
        for i in range(len(encryptedText)):
            file.write(str(encryptedText[i]))
            if i < (len(encryptedText)-1):
                file.write("\n")
        file.flush()
        file.close()

    def getEncryptedTextFromFile(self, filePath:str = "") -> list:
        file = open(filePath, "r")
        text = (file.read()).split("\n")
        if str(type(text)).find("list") == -1:
            text = [int(text)]
        else:
            for i in range(len(text)):
                text[i] = int(text[i])
        return text

    def getDecryptedTextFromFile(self, filePath:str = "") -> str:
        file = open(filePath, "r")
        return file.read()

if __name__ == "__main__":
    print(instrucciones)
    action = ""
    while (str(action).lower()).find("encrypt") == -1 and (str(action).lower()).find("decrypt") == -1 and (str(action).lower()).find("quit") == -1:
        print("\nType the action to realize:\n   Encrypt - Decrypt - Quit")
        action = input("")
    if(str(action).lower()).find("quit") == -1:
        seed = input("\nType a password: ")
        cp = Cryptography(seed)
        del seed
        fileIn = input("\nType the file name or file path to " + str(action).lower() + ":\n")
        fileOut = input("\nType the file name to copy the result:\n")
        print()
        if (str(action).lower()).find("encrypt") != -1:
            cp.encryptFile(fileIn, fileOut)
        else:
            cp.decryptFile(fileIn, fileOut)
        print("\nProcess finished.")
    else:
        print()