import { Cryptography } from "./Cryptography.js";

window.onload = () => {
    const bEncrypt = document.getElementById("button-encrypt");
    const bDecrypt = document.getElementById("button-decrypt");
    const inputTextToEncrypt = document.getElementById("text-to-encrypt");
    const inputPassEncrypter = document.getElementById("password-encrypter");
    const inputPassDecrypter = document.getElementById("password-decrypter");
    const textareaTextEncrypted = document.getElementById("text-encrypted");
    const textareaTextDecrypted = document.getElementById("text-decrypted");

    bEncrypt.addEventListener("click", () => {
        if (inputPassEncrypter.value.length > 0 && inputTextToEncrypt.value.length > 0) {
            document.querySelector(".encrypter-incomplete").classList.toggle("hide", true);
            const encrypted = encrypt(inputPassEncrypter.value, inputTextToEncrypt.value);
            textareaTextEncrypted.textContent = encrypted.join(",");
            document.querySelector(".decrypter-form").classList.remove("hide");
        } else document.querySelector(".encrypter-incomplete").classList.remove("hide");
    });

    bDecrypt.addEventListener("click", () => {
        if (textareaTextEncrypted.value.length > 0) {
            if (inputPassDecrypter.value.length > 0) {
                document.querySelector(".decrypter-incomplete").classList.toggle("hide", true);
                document.querySelector(".encrypted-incomplete").classList.toggle("hide", true);
                const encrypted = textareaTextEncrypted.textContent.split(",");
                const decrypted = decrypt(inputPassDecrypter.value, encrypted);
                textareaTextDecrypted.textContent = decrypted;
                document.querySelector(".decrypted-form").classList.remove("hide");
            } else {
                document.querySelector(".encrypted-incomplete").classList.toggle("hide", true);
                document.querySelector(".decrypter-incomplete").classList.remove("hide");
            }
        } else {
            document.querySelector(".decrypter-incomplete").classList.toggle("hide", true);
            document.querySelector(".encrypted-incomplete").classList.remove("hide");
        }
    });
}

function encrypt(password, text) {
    const cryptography = new Cryptography(password);
    cryptography.encryptText(text);
    return cryptography.getEncryptedText();
}

function decrypt(password, encrypted) {
    const cryptography = new Cryptography(password);
    cryptography.decryptText(encrypted);
    return cryptography.getDecryptedText();
}