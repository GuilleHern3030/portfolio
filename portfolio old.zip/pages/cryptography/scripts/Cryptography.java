package cryptography3;// 06/07/2022

/* Para utilizar esta class, es necesario instanciarla con la SEED con la cual se trabajará
 * Funciones:
    - encryptFile: encripta un archivo de texto, guardándolo en otro archivo
    - encryptText: encripta un texto y lo guarda como vector en 'textEncrypted'
        -> getEncryptedText: devuelve el vector 'textEncrypted'
    - decryptFile: decripta un archivo encryptado, guardándolo en otro archivo
    - decryptText: desencripta el vector 'textEncrypted' y lo guarda en 'textDecrypted'
        -> getDecryptedText: devuelve el texto de 'textDecrypted'
    - stopEncrypting: detiene el proceso de encriptado o desencriptado
    - clear: borra el contenido de los vectores 'textEncrypted' y 'textDecrypted'
    - setEmptyCharacterFrequencyRange: establece los rangos de frecuencia de aparicion de caracteres vacios
    - saveEncryptedTextInFile: guarda un texto encriptado en un archivo de texto
    - getEncryptedTextFromFile: obtiene el texto encriptado de un archivo de texto
    - getDecryptedTextFromFile: obtiene el texto de un archivo de texto

 * Listener:
    - onProgressUpdate(int progressPercent);
    - onProgressFinished();
    - onErrorDetected();
 */

/**
 * @author enel
 */
public class Cryptography {

    // Const
    public final static String DefaultFolderName = "cryptography3";
    public final static String FileExtends = "cpt";
    public final static int MAX_CHARACTERS = 24;
    public final static int RECOMENDED_MAX_LENGTH = 300000;
    private final long[] c;
    private final long[] d;
    private final long so;
    
    // Var
    private boolean encrypting = false;
    private int[] textEncrypted = null;// index 0 is max charId (ccLimit)
    private String textDecrypted = "";
    private int frequencyRangeNullMin = 3;
    private int frequencyRangeNullMax = 12;
    
    /**
     * @param seed user password to encode text
     */
    public Cryptography(String seed) {
        c = initializeC(seed);
        d = initializeD(c, seed.length());
        so = initializeSO(c, seed.length());
    }

    // <editor-fold defaultstate="collapsed" desc="Initialize atributes">
    private final static int CC_START = 30;
    private final static int CC_NULL = 30;
    private final static int CC_NL = 31;

    /**
     * @param p user password to encode text
     * @return vector with MAX_CHARACTERS int elements
     */
    private long[] initializeC(String p) {
        if(p.length() > MAX_CHARACTERS) p = p.substring(0,MAX_CHARACTERS+1);
        long[] c = new long[MAX_CHARACTERS];
        for(int i = 0; i < c.length; i++) c[i] = 0;
        for(int i = 0; i < MAX_CHARACTERS; i++) {
            long tmp;
            if(i < p.length()) {
                tmp = octal(p.substring(i,(i+1)).charAt(0));
            } else try {
                tmp = octal(c[i-p.length()]);
            } catch(Exception e) {
                tmp = octal(p.length());
            }
            c[i] = (long)tmp;
        }
        return c;
    }

    /**
     * @param c user password to encode text
     * @param pLength user password length
     * @return vector with MAX_CHARACTERS int elements
     */
    private long[] initializeD(long[] c, int pLength) {
        long[] d = new long[MAX_CHARACTERS];
        for(int i = 0; i < d.length; i++) d[i] = 0;
        long tmp = 0;
        int l = pLength; if(pLength == 0) l = MAX_CHARACTERS;
        if(c.length == d.length) for(int x = 0; x < MAX_CHARACTERS; x++) {
            tmp = x;
            try {
                switch(x) {
                    case 0: { tmp = (l-1); break; }
                    case 1: { tmp = (l+1); break; }
                    case 2: { tmp = ((l+13)/l); break; }
                    case 3: { tmp = (c[5]/(l*l+(l/2))); break; }
                    case 4: { tmp = d[2]+d[3]; break; }
                    case 5: { tmp = d[6]-d[1]; break; }
                    case 6: { tmp = c[23]/d[0]; break; }
                    case 7: { tmp = c[21]-c[12]; break; }
                    case 8: { tmp = c[10]*l/c[2]; break; }
                    case 9: { tmp = l-c[17]+d[10]; break; }
                    case 10:{ tmp = d[4]*l; break; }
                    case 11:{ tmp = l+5+d[7]; break; }
                    case 12:{ tmp = c[2]-c[6]+d[4]; break; }
                    case 13:{ tmp = d[8]-c[7]; break; }
                    case 14:{ tmp = c[15]-c[16]; break; }
                    case 15:{ tmp = d[5]-d[16]; break; }
                    case 16:{ tmp = c[20]/l; break; }
                    case 17:{ tmp = d[18]/d[16]; break; }
                    case 18:{ tmp = d[13]*d[19]/d[16]; break; }
                    case 19:{ tmp = d[17]+l+(d[19]*d[0]); break; }
                    case 20:{ tmp = c[7]/l; break; }
                    case 21:{ tmp = c[15]/d[22]; break; }
                    case 22:{ tmp = c[11]+l-d[14]/c[6]; break; }
                    case 23:{ tmp = d[1]/c[3]+l; break; }

                    default:{ tmp += d[(x-8)]*c[x-4]/pLength; break; }
                }
            } catch(Exception e) { tmp = pLength; }
            if(tmp == 0) tmp = (int)octal((pLength+x));
            if(tmp < 0) tmp*=-1;
            d[x] = tmp;
        }
        return d;
    }

    /**
     * @param c user password to encode text
     * @param pLength user password length
     * @return long octal value
     */
    private long initializeSO(long[] c, int pLength) {
        long so = 1;
        for(int i = 0; i < pLength; i++) {
            so += (octal(c[i])*(i+11));
        }
        return so;
    }
    // </editor-fold>

    public static void main(String[] args) {
        java.util.Scanner input = new java.util.Scanner(System.in);
        String action = "None";
        String fileIn = "", fileOut = "";
        do {
            log("Type the action to realize:");
            log("   Encrypt - Decrypt");
            action = input.nextLine();
        } while(!action.equalsIgnoreCase("encrypt") && !action.equalsIgnoreCase("decrypt"));
        log("Type a password:");
        Cryptography cryptography = new Cryptography(input.nextLine());
        log("");
        log("Type the file name or file path to " + action.equalsIgnoreCase("encrypt") + ":");
        fileIn = input.nextLine();
        log("");
        log("Type the file name to copy the result:");
        fileOut = input.nextLine();
        log("");
        if(action.equalsIgnoreCase("encrypt"))
            cryptography.encryptFile(fileIn, fileOut);
        else
            cryptography.decryptFile(fileIn, fileOut);
        log("\nProcess finished.");
        input.nextLine();
        input.close();
    }
    
    // Stops encrypting/decrypting process
    public void stopEncrypting() {
        encrypting = false;
    }
    
    // Adds a element in textEncrypted
    private void appendCryptography(int chr) {
        int[] _cryptography = new int[textEncrypted.length+1];
        System.arraycopy(textEncrypted, 0, _cryptography, 0, textEncrypted.length);
        _cryptography[textEncrypted.length] = chr;
        textEncrypted = _cryptography;
    }

    // Encrypt a text
    public void encryptText(final String text) {
        try {
            clear();
            encrypting = true;
            int ecfmax = frequencyRangeNullMax;
            int ecfmin = frequencyRangeNullMin;
            java.util.Random randomize = new java.util.Random(System.currentTimeMillis());
            final int ccLimit = getMaxCharInText(text);
            textEncrypted = new int[]{ccLimit};
            int r = (randomize.nextInt(ecfmax-ecfmin) - ecfmin);
            int chr = 0;
            int iteration = 1;
            while(encrypting && chr < text.length()) {
                if(r >= ecfmax) {
                    appendCryptography(encryptChar(text.substring(chr,chr+1), iteration, ccLimit, false));
                    r = (randomize.nextInt(ecfmax-ecfmin) - ecfmin);
                    chr++;
                } else {
                    appendCryptography(encryptChar(text.substring(chr,chr+1), iteration, ccLimit, true));
                    r++;
                }
                iteration++;
                try { progressUpdate.onProgressUpdate((iteration*100/text.length())); } catch(Exception ignored) { }
            }
            try { progressUpdate.onProgressFinished(); } catch(Exception ignored) { }
        } catch(Exception e) {
            try { progressUpdate.onErrorDetected(e.toString()); } catch(Exception ignored) { }
        }
        encrypting = false;
    }
    
    // Gets the textEncrypted vector
    public int[] getEncryptedText() { 
        return textEncrypted;
    }
    
    // Decrypt a textEncrypted vector
    public void decryptText(int[] textEncrypted) {
        try {
            if(textEncrypted == null || textEncrypted.length < 1)
                textEncrypted = this.textEncrypted;
            final int ccLimit = textEncrypted[0];
            encrypting = true;
            textDecrypted = "";
            int i = 1;
            while(encrypting && i < textEncrypted.length) {
                textDecrypted += (decryptCharAndParse(textEncrypted[i], i, ccLimit));
                i++;
                try { progressUpdate.onProgressUpdate((i*100/textEncrypted.length)); } catch(Exception ignored) { }
            }
            try { progressUpdate.onProgressFinished(); } catch(Exception ignored) { }
        } catch(Exception e) {
            try {
                String errorFormat = "\n";
                if(textEncrypted == null) errorFormat += "tE==null";
                else if(textEncrypted.length < 1) errorFormat += "tE==0";
                else errorFormat += "tE=="+textEncrypted.length;
                progressUpdate.onErrorDetected("[dt-e]"+e.toString()+errorFormat); 
            } catch(Exception ignored) { }
        }
        encrypting = false;
    }
    
    // Gets the text decrypted
    public String getDecryptedText() {
        return textDecrypted;
    }
    
    // Sets the frequency range of empty characters in encrypt process
    public void setEmptyCharacterFrequencyRange(int frequencyMin, int frequencyMax) {
        if(frequencyMax < 0) frequencyMax *= -1;
        if(frequencyMin < 0) frequencyMax *= -1;
        if(frequencyMax >= frequencyMin) {
            frequencyRangeNullMax = frequencyMax;
            frequencyRangeNullMin = frequencyMin;
        } else {
            frequencyRangeNullMax = frequencyMin;
            frequencyRangeNullMin = frequencyMax;
        }
        if(frequencyRangeNullMax == 0) 
            frequencyRangeNullMax = 1;
    }

    // Re-initialize the textEncrypted and textDecrypted vars
    public void clear() {
        textEncrypted = null;
        textDecrypted = "";
    }
    
    // Encrypt a file in another file path
    public void encryptFile(final String filePath, final String fileOutPath) {
        encrypting = true;
        java.io.File fileToEncrypt = new java.io.File(fPath(filePath,false));// Abre el archivo "./file.txt"
        final int ccLimit = getMaxCharInFile(fileToEncrypt);
        try(java.util.Scanner scanner = new java.util.Scanner(fileToEncrypt)){// permite escanear el texto
            try(java.io.PrintWriter writer = new java.io.PrintWriter(fPath(fileOutPath, true),"UTF-8")) { // Abrir archivo donde copiar el encriptado
                if(fileToEncrypt.exists() && fileToEncrypt.canRead()) {
                    java.util.Random randomize = new java.util.Random(System.currentTimeMillis());
                    int r = (randomize.nextInt(frequencyRangeNullMax-frequencyRangeNullMin) - frequencyRangeNullMin);
                    int iteration = 1;
                    int lineasLeidas = 0;
                    writer.print(String.valueOf(ccLimit));
                    try {
                        log("Encrypting file...");
                        while(encrypting && scanner.hasNextLine()) {
                            String linea = scanner.nextLine() + "\n";
                            for(int l = 0; l < linea.length(); l++) {
                                writer.println("");
                                int cc = 0;
                                if(r >= frequencyRangeNullMax) {
                                    cc = encryptChar(linea.substring(l,l+1), iteration, ccLimit, false);
                                    r = (randomize.nextInt(frequencyRangeNullMax-frequencyRangeNullMin) - frequencyRangeNullMin);
                                } else {
                                    cc = encryptChar(linea.substring(l,l+1), iteration, ccLimit, true);
                                    r++;
                                    l--;
                                }
                                writer.print(String.valueOf(cc));
                                iteration++;
                            }
                            lineasLeidas++;
                            log("Line " + lineasLeidas + " encrypted.");
                            try { progressUpdate.onProgressUpdate(lineasLeidas); } catch(Exception ignored) { }
                        }
                        log("Encrypt file finished.");
                        try { progressUpdate.onProgressFinished(); } catch(Exception ignored) { }
                    } catch(NullPointerException e) {
                        try { progressUpdate.onErrorDetected(e.toString()); } catch(Exception ignored) { }
                        log("\n[FILE ENCRYIPTING ERROR] The file is not readable.\n"+e.toString());
                    }
                } else {
                    try { progressUpdate.onErrorDetected("File not exists?"); } catch(Exception ignored) { }
                    log("\n[FILE ENCRYIPTING ERROR] The file is not readable.");
                }
                writer.close();
            } catch(java.io.UnsupportedEncodingException e) { 
                try { progressUpdate.onErrorDetected(e.toString()); } catch(Exception ignored) { }
                log("\n[FILE ENCRYIPTING ERROR] Write in the new file encrypted is impossbile.\n"+e.toString());
            }
            scanner.close();
        } catch(java.io.FileNotFoundException e) {
            try { progressUpdate.onErrorDetected(e.toString()); } catch(Exception ignored) { }
            log("\n[FILE ENCRYIPTING ERROR] The file to encrypt isn't exists.\n"+e.toString());
        }
        encrypting = false;
    }
    
    // Decrypt a encrypted file in another file path
    public void decryptFile(final String filePath, final String fileOutPath) {
        encrypting = true;
        java.io.File fileToDecrypt = new java.io.File(fPath(filePath, true));// Abre el archivo "./file.text"
        try(java.util.Scanner scanner = new java.util.Scanner(fileToDecrypt)){// permite escanear el texto
            try(java.io.PrintWriter writer = new java.io.PrintWriter(fPath(fileOutPath, false),"UTF-8")) { // Abrir archivo donde copiar el texto desencriptado
                if(fileToDecrypt.exists() && fileToDecrypt.canRead()) {
                    try {
                        int iteration = 1;
                        int ccLimit = 255;
                        if(scanner.hasNextLine())
                            ccLimit = Integer.parseInt(scanner.nextLine());
                        log("Decrypting file...");
                        while(encrypting && scanner.hasNextLine()) {
                            int cc = Integer.parseInt(scanner.nextLine());
                            String chr = decryptCharAndParse(cc, iteration, ccLimit);
                            try { 
                                writer.print(chr);
                            } catch(Exception ignored) { }
                            iteration++;
                        }
                        try { progressUpdate.onProgressFinished(); } catch(Exception ignored) { }
                        log("Decrypt file finished.");
                    } catch(NumberFormatException e) {
                        try { progressUpdate.onErrorDetected("[df-nfe]"+e.toString()); } catch(Exception ignored) { }
                        log("\n[FILE DECRYPTING ERROR] Format of file to decrypt is not supported\n"+e.toString());
                    }
                } else {
                    try { progressUpdate.onErrorDetected("[df-fne]File not exists?"); } catch(Exception ignored) { }
                    log("\n[FILE DECRYPTING ERROR] The file isn't exists.");
                }
                writer.close();
            } catch(java.io.UnsupportedEncodingException e) {
                try { progressUpdate.onErrorDetected("[df-uee]"+e.toString()); } catch(Exception ignored) { }
                log("\n[FILE DECRYPTING ERROR] Write in the new file is impossible.\n"+e.toString());
            }
            scanner.close();
        } catch(java.io.FileNotFoundException e) {
            try { progressUpdate.onErrorDetected("[df-fnfe]"+e.toString()); } catch(Exception ignored) { }
            log("\n[FILE DECRYPTING ERROR] The encrypted file isn't exists.\n"+e.toString());
        }
        encrypting = false;
    }

    // Saves a encrypted text in a extern file
    public void saveEncryptedTextInFile(int[] encryptedText, String fileOutPath) {
        try(java.io.PrintWriter writer = new java.io.PrintWriter(fPath(fileOutPath, false),"UTF-8")) {
            for(int i = 0; i < encryptedText.length-1; i++) {
                writer.println(String.valueOf(encryptedText[i]));
            }
            writer.print(encryptedText[encryptedText.length-1]);
            writer.close();
        } catch(Exception e) {
            log("\n[SAVING ENCRYPTED ERROR] Impossible create a new file in the specified path.\nFolder not exists?\n"+e.toString());
        }
    }
    
    // Gets a encrypted text from a encrypted file
    public int[] getEncryptedTextFromFile(final String filePath) {
        int[] encrypted = new int[]{};
        java.io.File fileEncrypted = new java.io.File(fPath(filePath,false));
        try(java.util.Scanner scanner = new java.util.Scanner(fileEncrypted)){
            try {
                if(scanner.hasNextLine()) {
                    String ccLimit = scanner.nextLine();
                    encrypted = new int[]{Integer.parseInt(ccLimit)};
                }
                while(scanner.hasNextLine()) {
                    String linea = scanner.nextLine();
                    int value = Integer.parseInt(linea);
                    int tmp[] = encrypted;
                    encrypted = new int[tmp.length+1];
                    System.arraycopy(tmp, 0, encrypted, 0, tmp.length);
                    encrypted[tmp.length] = value;
                }
            } catch(NumberFormatException e) {
                log("\n[LOAD FILE ENCRYPTED ERROR] The file hasn't correct format.\n"+e.toString());
            }
        } catch(Exception e) {
            log("\n[ERROR] The file isn't exists.\n"+e.toString());
        }
        if(encrypted == null) log("\n[LOAD FILE ENCRYPTED ERROR] Can not get the encrypted text from file (null).\n");
        else if(encrypted.length <= 1) log("\n[LOAD FILE ENCRYPTED ERROR] Can not get the encrypted text from file.\n");
        return encrypted;
    }
    
    // Gets a text from a decrypted file
    public String getDecryptedTextFromFile(String filePath) {
        String text = "";
        java.io.File fileDecrypted = new java.io.File(fPath(filePath,false));
        try(java.util.Scanner scanner = new java.util.Scanner(fileDecrypted)){
            try {
                while(encrypting && scanner.hasNextLine())
                    text += scanner.nextLine() + "\n";
            } catch(Exception e) {
                log("\n[ERROR] The file is not readable.\n"+e.toString());
            }
        } catch(Exception e) {
            log("\n[ERROR] The file isn't exists.\n"+e.toString());
        }
        return text.substring(0,text.length()-1);
    }
    
    // <editor-fold defaultstate="collapsed" desc="Listener">
    private OnProgressUpdateListener progressUpdate;
    // My listener
    public interface OnProgressUpdateListener {
        void onProgressUpdate(int progressPercent);
        void onProgressFinished();
        void onErrorDetected(String errorInfo);
    }
    public void setOnProgressUpdateListener(OnProgressUpdateListener progressUpdate) {
        this.progressUpdate = progressUpdate;
    }// </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Specific functions">
    private long octal(long n) {
        try {
            return Long.parseLong(Long.toOctalString(n));
        } catch(NumberFormatException e) {
            return n;
        }
    }

    private int getMaxCharInText(String text) {
        int maxChar = 0;
        try {
            if (text.length() > 0) {
                for (int i = 0; i < text.length(); i++) {
                    char l = text.charAt(i);
                    if(l > maxChar) maxChar = (int)(l);
                }
            }
        } catch(Exception ignored) { 
            maxChar = 255;
        }
        if(maxChar < CC_START) maxChar = 255;
        java.util.Random randomize = new java.util.Random(System.currentTimeMillis());
        maxChar += (randomize.nextInt(MAX_CHARACTERS)) + CC_START;
        return maxChar;
    }
    
    private int getMaxCharInFile(java.io.File file) {
        int maxChar = 0;
        try(java.util.Scanner scanner = new java.util.Scanner(file)) {
            while(scanner.hasNextLine()) {
                int maxCharInLine = getMaxCharInText(scanner.nextLine());
                if(maxCharInLine > maxChar) maxChar = maxCharInLine;
            }
            scanner.close();
        } catch(Exception ignored) {
            maxChar = 255;
        }
        java.util.Random randomize = new java.util.Random(System.currentTimeMillis());
        return maxChar + (randomize.nextInt(MAX_CHARACTERS));
    }
    
    private String fPath(final String path, boolean fileEncrypted) {
        String fPath = path;
        if(!path.contains("\\")) {
            if(!path.contains("/")) fPath = "./" + path;
            if(!path.contains(".")) {
                if(fileEncrypted) fPath += "." + FileExtends;
                else fPath += ".txt";
            }
        }
        return fPath;
    }

    private int parseCharToCryptoChar(String charr) {
        int crch = 63;// ?
        if(charr.equals("")) crch = CC_NULL;
        else if(charr.equals("\n")) crch = CC_NL;
        else if(charr.length() == 1) {
            try {
                char ch = charr.charAt(0);
                crch = (int)ch;
            } catch(Exception e) { }
        }
        return crch;
    }

    private String parseCryptoCharToString(int l) {
        if(l == CC_NL) return "\n";
        else if(l == CC_NULL) return "";
        String tmp = ""; tmp += ((char)l);
        return tmp;
    }
    
    /**
     * @param character letra que se quiere encriptar
     * @param iteration cantidad de veces que se utilizó la función en el proceso de encriptado
     * @param ccLimit el char máximo que existe en el texto original (default = 255)
     * @param falseEncrypt encripta un caracter vacío si es true
     * @return char encriptado
     */
    private int encryptChar(final String character, final long iteration, final int ccLimit, final boolean falseEncrypt) {
        int crypto = -1;
        if(character.length() == 1) {
            int x = (int)(iteration%c.length);
            int y = (int)(iteration/c.length)%c.length;
            int z = (int)((iteration/c.length)/c.length);
            long soi = ((so+iteration)*(z+ccLimit))*(int)c[x]/(int)d[y];
            if(soi < 0) soi *= -1;
            int tmp = 0;
            int cryptoChar = parseCharToCryptoChar(character);
            while(!falseEncrypt && tmp != cryptoChar || falseEncrypt && tmp != CC_NULL) {
                crypto++;
                long integer = ((soi)*c[y]/d[x] + crypto) % ccLimit;
                if(integer < CC_START) integer = (integer*(ccLimit-CC_START)/CC_START)+CC_START;
                tmp = (int)integer;
            }
        }
        return crypto;
    }
    
    /**
     * @param cryptoChar numero (letra encriptada) que se quiere desencriptar
     * @param iteration cantidad de veces que se utilizó la función en el proceso de desencriptado
     * @param ccLimit el char máximo que existe en el texto original (default = 255)
     * @return char desencriptado
     */
    private int decryptChar(final int cryptoChar, final long iteration, final int ccLimit) {
        int x = (int)(iteration%c.length);
        int y = (int)(iteration/c.length)%c.length;
        int z = (int)((iteration/c.length)/c.length);
        long soi = ((so+iteration)*(z+ccLimit))*(int)c[x]/(int)d[y];
        if(soi < 0) soi *= -1;
        long integer = ((soi)*c[y]/d[x] + cryptoChar) % ccLimit;
        if(integer < CC_START) integer = (integer*(ccLimit-CC_START)/CC_START)+CC_START;
        return (int)integer;
    }
    private String decryptCharAndParse(final int cryptoChar, final long iteration, final int ccLimit) {
        int _cryptoChar = decryptChar(cryptoChar, iteration, ccLimit);
        return parseCryptoCharToString(_cryptoChar);
    }
    // </editor-fold>

    private static void log(String text) {
        System.out.println(text);
    }
}