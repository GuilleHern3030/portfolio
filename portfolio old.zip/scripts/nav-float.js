const responsive_nav = document.getElementsByTagName("responsive-float-nav")[0];
const bars = responsive_nav.children[0];
const menu = responsive_nav.children[1];

menu.style.display = "none";

const hideMenu = () => {
    responsive_nav.classList.toggle("responsive-float-nav__inactive", true);
    responsive_nav.classList.toggle("responsive-float-nav__active", false);
}

const showMenu = () => {
    responsive_nav.classList.toggle("responsive-float-nav__active", true);
    responsive_nav.classList.toggle("responsive-float-nav__inactive", false);
}

bars.addEventListener("click", () => {
    if (responsive_nav.classList.contains("responsive-float-nav__active")) hideMenu();
    else if(responsive_nav.classList.contains("responsive-float-nav__inactive")) showMenu();
    else if(menu.style.display == "none") showMenu();
    else hideMenu();
});